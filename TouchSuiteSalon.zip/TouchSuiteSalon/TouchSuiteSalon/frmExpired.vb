﻿Public Class frmExpired

    Private Sub frmExpired_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TouchSalonSystemDataSet2.tblCustomerInfo' table. You can move, or remove it, as needed.
        'Me.TblCustomerInfoTableAdapter.Fill(Me.TouchSalonSystemDataSet2.tblCustomerInfo)
        lblMonth.Text = Format(Now, "MMMM")
       
    End Sub

 
    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Me.Close()

    End Sub
End Class