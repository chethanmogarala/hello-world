﻿Public Class frmProductsReport

    Private Sub frmProductsReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TouchSalonSystemDataSet4.tblPrices' table. You can move, or remove it, as needed.
        'Me.tblPricesTableAdapter.Fill(Me.TouchSalonSystemDataSet4.tblPrices)
        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class