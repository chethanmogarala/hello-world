delimiter $$

CREATE TABLE `tblcomments` (
  `ID` int(11) NOT NULL,
  `Comments` varchar(45) DEFAULT NULL,
  `CommentsDate` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$

delimiter $$

CREATE TABLE `tblcustomerinfo` (
  `MembersID` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Birthday` varchar(45) DEFAULT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `Subdivision` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `ContactNo` varchar(45) DEFAULT NULL,
  `EmailAddress` varchar(45) DEFAULT NULL,
  `Membership` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`MembersID`)
) ENGINE=InnoDB AUTO_INCREMENT=1113 DEFAULT CHARSET=latin1$$




delimiter $$

CREATE TABLE `tblprices` (
  `ProductID` int(11) NOT NULL,
  `Product` varchar(45) DEFAULT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Prices` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$

delimiter $$

CREATE TABLE `tblproductbilling` (
  `ID` int(11) NOT NULL,
  `MembersID` varchar(45) DEFAULT NULL,
  `FullName` varchar(45) DEFAULT NULL,
  `Category1` varchar(45) DEFAULT NULL,
  `Category2` varchar(45) DEFAULT NULL,
  `Category3` varchar(45) DEFAULT NULL,
  `Category4` varchar(45) DEFAULT NULL,
  `Category5` varchar(45) DEFAULT NULL,
  `Product1` varchar(50) DEFAULT NULL,
  `Product2` varchar(50) DEFAULT NULL,
  `Product3` varchar(45) DEFAULT NULL,
  `Product4` varchar(45) DEFAULT NULL,
  `Product5` varchar(50) DEFAULT NULL,
  `Price1` varchar(45) DEFAULT NULL,
  `Price2` varchar(45) DEFAULT NULL,
  `Price3` varchar(45) DEFAULT NULL,
  `Price4` varchar(45) DEFAULT NULL,
  `Price5` varchar(45) DEFAULT NULL,
  `Quantity1` varchar(45) DEFAULT NULL,
  `Quantity2` varchar(45) DEFAULT NULL,
  `Quantity3` varchar(45) DEFAULT NULL,
  `Quantity4` varchar(45) DEFAULT NULL,
  `Quantity5` varchar(45) DEFAULT NULL,
  `Total` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tblproductnprice` (
  `ID` int(11) NOT NULL,
  `Product` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tblproducts` (
  `ID` int(11) NOT NULL,
  `Product` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `Image` mediumtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tblservices` (
  `ID` int(11) NOT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Services` varchar(45) DEFAULT NULL,
  `Price` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tblservicesimage` (
  `ID` int(11) NOT NULL,
  `Service` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `Image` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tblstaffaccess` (
  `StaffID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Access` varchar(45) DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$


delimiter $$

CREATE TABLE `tbluser` (
  `ID` int(11) NOT NULL,
  `UserName` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Auth` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1$$





