﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmStaffAvailability

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub frmStaffAvailability_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        conn = GetConnect()
        Try
            conn.Open()
            cmd = New MySqlCommand("Select * from tblStaffAccess where Name = '" & frmStaffLogin.txtUserName.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    lblRepName.Text = read("Name".ToString)
                    ' lblUserName.Text = read("UserName".ToString)
                End While
            Else
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        lblTime.Text = TimeOfDay
        lblTime.Text = Format(Now, "HH:mm:ss")
    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Update tblStaffAccess set status = '" & cmbAvailability.Text & "' where Name = '" & lblRepName.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            'conn.Close()
            MsgBox("Record Updated Successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Me.Close()


    End Sub

    Private Sub ToolStripStatusLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel1.Click

    End Sub
End Class