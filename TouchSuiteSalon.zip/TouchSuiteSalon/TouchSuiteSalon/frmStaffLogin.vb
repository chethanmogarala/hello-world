﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmStaffLogin
    Dim ctr As Integer
    Private Sub frmStaffLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Select Name, Password from tblStaffAccess where Name = '" & Trim(txtUserName.Text) & "' and Password = '" & Trim(txtPassword.Text) & "'"
            cmd = New MySqlCommand(str, conn)
            dr = cmd.ExecuteReader
            If dr.HasRows = True Then


                Dim frmStaffAvailability As New frmStaffAvailability

                frmStaffAvailability.Show()
                Me.Hide()

            ElseIf txtUserName.Text = "" Or txtPassword.Text = "" Then
            MsgBox("Enter Value!")
            txtUserName.Text = ""
            ctr = ctr - 1
            If ctr = 0 Then
                'MessageBox.Show("You entered 3 times incorrect !")
                MsgBox("You already tried 3 incorrect username or passowrd. Try again Later", _
           vbCritical, "Restricted Access!")

                End
            End If
            Else
            MsgBox("Invalid UserName/Password")
            txtUserName.Text = ""
            txtPassword.Text = ""
            txtUserName.Focus()
            ctr = ctr - 1
            If ctr = 0 Then
                MsgBox("You already tried 3 incorrect username or passowrd. Try again Later", _
           vbCritical, "Restricted Access!")

                End
            End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        dr.Close()
        conn.Close()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()


    End Sub
End Class