﻿Public Class frmCashierMenu

    Private Sub btnAboutUS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAboutUS.Click
        FrmBillingType.Show()


    End Sub

    Private Sub btnServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnServices.Click
        frmCashierStaff.Show()

    End Sub

    Private Sub btnClients_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClients.Click
        frmCashierMembers.Show()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub
End Class