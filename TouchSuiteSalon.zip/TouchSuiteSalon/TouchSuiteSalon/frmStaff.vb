﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmStaff

    Private Sub frmStaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtName.Focus()

        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblEmployee", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblEmployee")
            txtEmployeeID.DataSource = ds.Tables("tblEmployee")
            '---------------------------------------------------------



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtEmployeeID.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = txtEmployeeID.CurrentRow.Index
        txtEmployeeID.Text = txtEmployeeID.Item(0, i).Value
        txtName.Text = txtEmployeeID.Item(1, i).Value
        cboGender.Text = txtEmployeeID.Item(2, i).Value
        txtAge.Text = txtEmployeeID.Item(3, i).Value
        txtAddress.Text = txtEmployeeID.Item(4, i).Value
        txtContact.Text = txtEmployeeID.Item(5, i).Value
        txtEmail.Text = txtEmployeeID.Item(6, i).Value
        txtPosition.Text = txtEmployeeID.Item(7, i).Value

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        conn = GetConnect()


        Try
            conn.Open()
            str = "Insert into tblEmployee values ('" & txtName.Text & "','" & cboGender.Text & "','" & txtAge.Text & "', '" & txtAddress.Text & "', '" & txtContact.Text & "', '" & txtEmail.Text & "', '" & txtPosition.Text & "')"

            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

        txtName.Text = ""
        cboGender.Text = ""
        txtAge.Text = ""
        txtAddress.Text = ""
        txtContact.Text = ""
        txtEmail.Text = ""
        txtPosition.Text = ""

        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblEmployee", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblEmployee")
            txtEmployeeID.DataSource = ds.Tables("tblEmployee")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        txtEmployeeID.Refresh()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtName.Text = ""
        cboGender.Text = ""
        txtAge.Text = ""
        txtAddress.Text = ""
        txtContact.Text = ""
        txtEmail.Text = ""
        txtPosition.Text = ""
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class