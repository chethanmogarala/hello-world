﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Public Class frmOrderLogin
    Dim ctr As Integer
    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        conn = GetConnect()

        Try

            conn.Open()
            str = "Select MembersID from tblCustomerInfo where MembersID = '" & Trim(txtMemberID.Text) & "'"
            cmd = New MySqlCommand(str, conn)
            dr = cmd.ExecuteReader
            If dr.HasRows = True Then

                Dim frmProducts2 As New frmProducts2

                frmOrder.Show()
                Me.Hide()
                frmProducts.Close()


            ElseIf txtMemberID.Text = "" Then
                MsgBox("Enter Value!")
                txtMemberID.Text = ""

            Else
                MsgBox("Incorrect Member ID")
                txtMemberID.Text = ""
                ctr = ctr - 1
                If ctr = 0 Then

                    MsgBox("You already tried 3 incorrect Member ID. Please contact Administration", _
               vbCritical, "Restricted Access!")

                    End
                End If
            End If
            dr.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        conn.Close()
    End Sub

    Private Sub frmOrderLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtMemberID.Focus()
        ctr = 3
    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label15.Click

    End Sub

    Private Sub txtMemberID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMemberID.TextChanged

    End Sub
End Class