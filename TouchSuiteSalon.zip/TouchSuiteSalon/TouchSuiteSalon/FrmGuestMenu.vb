﻿Public Class FrmGuestMenu

    Private Sub btnClients_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClients.Click
        FrmServices.Show()

    End Sub

    
    Private Sub btnStaff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaff.Click
        FrmAvailableStaff.Show()

    End Sub

    Private Sub btnProducts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProducts.Click
        frmProducts3.Show()
    End Sub

    Private Sub btnReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReports.Click
        frmComment.Show()

    End Sub

    Private Sub btnAboutUS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAboutUS.Click
        frmAboutUs.Show()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub
End Class