﻿Public Class FrmStaffReport

    Private Sub FrmStaffReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TouchSalonSystemStaff.tblEmployee' table. You can move, or remove it, as needed.
        'Me.tblEmployeeTableAdapter.Fill(Me.TouchSalonSystemStaff.tblEmployee)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
        Me.Close()

    End Sub
End Class