﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmService
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmService))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCustomerName1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCustomerName = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnAdd1 = New System.Windows.Forms.Button()
        Me.txtPrice1 = New System.Windows.Forms.TextBox()
        Me.lblPrice1 = New System.Windows.Forms.Label()
        Me.cmbService1 = New System.Windows.Forms.ComboBox()
        Me.TblServicesBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemService1 = New TouchSuiteSalon.TouchSalonSystemService1()
        Me.lblService1 = New System.Windows.Forms.Label()
        Me.cmbCategory1 = New System.Windows.Forms.ComboBox()
        Me.TblServicesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory_11 = New TouchSuiteSalon.TouchSalonSystemCategory_11()
        Me.lblCategory1 = New System.Windows.Forms.Label()
        Me.btnAdd2 = New System.Windows.Forms.Button()
        Me.txtPrice2 = New System.Windows.Forms.TextBox()
        Me.lblPrice2 = New System.Windows.Forms.Label()
        Me.cmbService2 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemService2 = New TouchSuiteSalon.TouchSalonSystemService2()
        Me.TblServicesBindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblService2 = New System.Windows.Forms.Label()
        Me.cmbCategory2 = New System.Windows.Forms.ComboBox()
        Me.TblServicesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory_2 = New TouchSuiteSalon.TouchSalonSystemCategory_2()
        Me.lblCategory2 = New System.Windows.Forms.Label()
        Me.btnAdd3 = New System.Windows.Forms.Button()
        Me.txtPrice3 = New System.Windows.Forms.TextBox()
        Me.lblPrice3 = New System.Windows.Forms.Label()
        Me.cmbService3 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemService3 = New TouchSuiteSalon.TouchSalonSystemService3()
        Me.TblServicesBindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblService3 = New System.Windows.Forms.Label()
        Me.cmbCategory3 = New System.Windows.Forms.ComboBox()
        Me.TblServicesBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory_3 = New TouchSuiteSalon.TouchSalonSystemCategory_3()
        Me.lblCategory3 = New System.Windows.Forms.Label()
        Me.txtPrice4 = New System.Windows.Forms.TextBox()
        Me.lblPrice4 = New System.Windows.Forms.Label()
        Me.cmbService4 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemService4 = New TouchSuiteSalon.TouchSalonSystemService4()
        Me.TblServicesBindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblService4 = New System.Windows.Forms.Label()
        Me.cmbCategory4 = New System.Windows.Forms.ComboBox()
        Me.TblServicesBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory_4 = New TouchSuiteSalon.TouchSalonSystemCategory_4()
        Me.lblCategory4 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtAllTotal = New System.Windows.Forms.TextBox()
        Me.btnOrder5 = New System.Windows.Forms.Button()
        Me.TblServicesTableAdapter1 = New TouchSuiteSalon.TouchSalonSystemCategory_2TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter = New TouchSuiteSalon.TouchSalonSystemCategory_11TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter2 = New TouchSuiteSalon.TouchSalonSystemCategory_3TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter3 = New TouchSuiteSalon.TouchSalonSystemCategory_4TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter4 = New TouchSuiteSalon.TouchSalonSystemService1TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter5 = New TouchSuiteSalon.TouchSalonSystemService2TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter6 = New TouchSuiteSalon.TouchSalonSystemService3TableAdapters.tblServicesTableAdapter()
        Me.TblServicesTableAdapter7 = New TouchSuiteSalon.TouchSalonSystemService4TableAdapters.tblServicesTableAdapter()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.TblServicesBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemService1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory_11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemService2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemService3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemService4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicesBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory_4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.lblCustomerName1, Me.ToolStripStatusLabel1, Me.lblCustomerName})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 405)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(906, 31)
        Me.StatusStrip1.TabIndex = 161
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(133, 26)
        Me.ToolStripStatusLabel2.Text = "Customer ID:"
        '
        'lblCustomerName1
        '
        Me.lblCustomerName1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblCustomerName1.ForeColor = System.Drawing.Color.Gold
        Me.lblCustomerName1.Name = "lblCustomerName1"
        Me.lblCustomerName1.Size = New System.Drawing.Size(66, 26)
        Me.lblCustomerName1.Text = "Name"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(164, 26)
        Me.ToolStripStatusLabel1.Text = "Customer Name:"
        '
        'lblCustomerName
        '
        Me.lblCustomerName.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblCustomerName.ForeColor = System.Drawing.Color.Gold
        Me.lblCustomerName.Name = "lblCustomerName"
        Me.lblCustomerName.Size = New System.Drawing.Size(66, 26)
        Me.lblCustomerName.Text = "Name"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDate.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.White
        Me.lblDate.Location = New System.Drawing.Point(678, 26)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(0, 17)
        Me.lblDate.TabIndex = 163
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(595, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 17)
        Me.Label10.TabIndex = 162
        Me.Label10.Text = "Date: "
        '
        'btnAdd1
        '
        Me.btnAdd1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd1.FlatAppearance.BorderSize = 2
        Me.btnAdd1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd1.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd1.Location = New System.Drawing.Point(736, 81)
        Me.btnAdd1.Name = "btnAdd1"
        Me.btnAdd1.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd1.TabIndex = 173
        Me.btnAdd1.Text = "Add to Cart"
        Me.btnAdd1.UseVisualStyleBackColor = True
        '
        'txtPrice1
        '
        Me.txtPrice1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice1.Location = New System.Drawing.Point(598, 83)
        Me.txtPrice1.Name = "txtPrice1"
        Me.txtPrice1.ReadOnly = True
        Me.txtPrice1.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice1.TabIndex = 169
        '
        'lblPrice1
        '
        Me.lblPrice1.AutoSize = True
        Me.lblPrice1.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice1.ForeColor = System.Drawing.Color.White
        Me.lblPrice1.Location = New System.Drawing.Point(540, 85)
        Me.lblPrice1.Name = "lblPrice1"
        Me.lblPrice1.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice1.TabIndex = 168
        Me.lblPrice1.Text = "Price: "
        '
        'cmbService1
        '
        Me.cmbService1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblServicesBindingSource4, "Services", True))
        Me.cmbService1.DataSource = Me.TblServicesBindingSource4
        Me.cmbService1.DisplayMember = "Services"
        Me.cmbService1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbService1.FormattingEnabled = True
        Me.cmbService1.Location = New System.Drawing.Point(368, 85)
        Me.cmbService1.Name = "cmbService1"
        Me.cmbService1.Size = New System.Drawing.Size(157, 24)
        Me.cmbService1.TabIndex = 167
        Me.cmbService1.ValueMember = "Services"
        '
        'TblServicesBindingSource4
        '
        Me.TblServicesBindingSource4.DataMember = "tblServices"
        Me.TblServicesBindingSource4.DataSource = Me.TouchSalonSystemService1
        '
        'TouchSalonSystemService1
        '
        Me.TouchSalonSystemService1.DataSetName = "TouchSalonSystemService1"
        Me.TouchSalonSystemService1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblService1
        '
        Me.lblService1.AutoSize = True
        Me.lblService1.BackColor = System.Drawing.Color.Transparent
        Me.lblService1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService1.ForeColor = System.Drawing.Color.White
        Me.lblService1.Location = New System.Drawing.Point(290, 89)
        Me.lblService1.Name = "lblService1"
        Me.lblService1.Size = New System.Drawing.Size(69, 20)
        Me.lblService1.TabIndex = 166
        Me.lblService1.Text = "Service: "
        '
        'cmbCategory1
        '
        Me.cmbCategory1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblServicesBindingSource, "Category", True))
        Me.cmbCategory1.DataSource = Me.TblServicesBindingSource
        Me.cmbCategory1.DisplayMember = "Category"
        Me.cmbCategory1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory1.FormattingEnabled = True
        Me.cmbCategory1.Location = New System.Drawing.Point(115, 87)
        Me.cmbCategory1.Name = "cmbCategory1"
        Me.cmbCategory1.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory1.TabIndex = 165
        Me.cmbCategory1.ValueMember = "Category"
        '
        'TblServicesBindingSource
        '
        Me.TblServicesBindingSource.DataMember = "tblServices"
        Me.TblServicesBindingSource.DataSource = Me.TouchSalonSystemCategory_11
        '
        'TouchSalonSystemCategory_11
        '
        Me.TouchSalonSystemCategory_11.DataSetName = "TouchSalonSystemCategory_11"
        Me.TouchSalonSystemCategory_11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblCategory1
        '
        Me.lblCategory1.AutoSize = True
        Me.lblCategory1.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory1.ForeColor = System.Drawing.Color.White
        Me.lblCategory1.Location = New System.Drawing.Point(9, 89)
        Me.lblCategory1.Name = "lblCategory1"
        Me.lblCategory1.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory1.TabIndex = 164
        Me.lblCategory1.Text = "Category: "
        '
        'btnAdd2
        '
        Me.btnAdd2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd2.FlatAppearance.BorderSize = 2
        Me.btnAdd2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd2.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd2.Location = New System.Drawing.Point(736, 136)
        Me.btnAdd2.Name = "btnAdd2"
        Me.btnAdd2.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd2.TabIndex = 180
        Me.btnAdd2.Text = "Add to Cart"
        Me.btnAdd2.UseVisualStyleBackColor = True
        Me.btnAdd2.Visible = False
        '
        'txtPrice2
        '
        Me.txtPrice2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice2.Location = New System.Drawing.Point(598, 138)
        Me.txtPrice2.Name = "txtPrice2"
        Me.txtPrice2.ReadOnly = True
        Me.txtPrice2.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice2.TabIndex = 179
        Me.txtPrice2.Visible = False
        '
        'lblPrice2
        '
        Me.lblPrice2.AutoSize = True
        Me.lblPrice2.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice2.ForeColor = System.Drawing.Color.White
        Me.lblPrice2.Location = New System.Drawing.Point(540, 140)
        Me.lblPrice2.Name = "lblPrice2"
        Me.lblPrice2.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice2.TabIndex = 178
        Me.lblPrice2.Text = "Price: "
        Me.lblPrice2.Visible = False
        '
        'cmbService2
        '
        Me.cmbService2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemService2, "tblServices.Services", True))
        Me.cmbService2.DataSource = Me.TblServicesBindingSource5
        Me.cmbService2.DisplayMember = "Services"
        Me.cmbService2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbService2.FormattingEnabled = True
        Me.cmbService2.Location = New System.Drawing.Point(368, 140)
        Me.cmbService2.Name = "cmbService2"
        Me.cmbService2.Size = New System.Drawing.Size(157, 24)
        Me.cmbService2.TabIndex = 177
        Me.cmbService2.ValueMember = "Services"
        Me.cmbService2.Visible = False
        '
        'TouchSalonSystemService2
        '
        Me.TouchSalonSystemService2.DataSetName = "TouchSalonSystemService2"
        Me.TouchSalonSystemService2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblServicesBindingSource5
        '
        Me.TblServicesBindingSource5.DataMember = "tblServices"
        Me.TblServicesBindingSource5.DataSource = Me.TouchSalonSystemService2
        '
        'lblService2
        '
        Me.lblService2.AutoSize = True
        Me.lblService2.BackColor = System.Drawing.Color.Transparent
        Me.lblService2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService2.ForeColor = System.Drawing.Color.White
        Me.lblService2.Location = New System.Drawing.Point(290, 144)
        Me.lblService2.Name = "lblService2"
        Me.lblService2.Size = New System.Drawing.Size(69, 20)
        Me.lblService2.TabIndex = 176
        Me.lblService2.Text = "Service: "
        Me.lblService2.Visible = False
        '
        'cmbCategory2
        '
        Me.cmbCategory2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblServicesBindingSource1, "Category", True))
        Me.cmbCategory2.DataSource = Me.TblServicesBindingSource1
        Me.cmbCategory2.DisplayMember = "Category"
        Me.cmbCategory2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory2.FormattingEnabled = True
        Me.cmbCategory2.Location = New System.Drawing.Point(115, 142)
        Me.cmbCategory2.Name = "cmbCategory2"
        Me.cmbCategory2.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory2.TabIndex = 175
        Me.cmbCategory2.ValueMember = "Category"
        Me.cmbCategory2.Visible = False
        '
        'TblServicesBindingSource1
        '
        Me.TblServicesBindingSource1.DataMember = "tblServices"
        Me.TblServicesBindingSource1.DataSource = Me.TouchSalonSystemCategory_2
        '
        'TouchSalonSystemCategory_2
        '
        Me.TouchSalonSystemCategory_2.DataSetName = "TouchSalonSystemCategory_2"
        Me.TouchSalonSystemCategory_2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblCategory2
        '
        Me.lblCategory2.AutoSize = True
        Me.lblCategory2.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory2.ForeColor = System.Drawing.Color.White
        Me.lblCategory2.Location = New System.Drawing.Point(9, 144)
        Me.lblCategory2.Name = "lblCategory2"
        Me.lblCategory2.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory2.TabIndex = 174
        Me.lblCategory2.Text = "Category: "
        Me.lblCategory2.Visible = False
        '
        'btnAdd3
        '
        Me.btnAdd3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd3.FlatAppearance.BorderSize = 2
        Me.btnAdd3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd3.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd3.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd3.Location = New System.Drawing.Point(736, 193)
        Me.btnAdd3.Name = "btnAdd3"
        Me.btnAdd3.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd3.TabIndex = 187
        Me.btnAdd3.Text = "Add to Cart"
        Me.btnAdd3.UseVisualStyleBackColor = True
        Me.btnAdd3.Visible = False
        '
        'txtPrice3
        '
        Me.txtPrice3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice3.Location = New System.Drawing.Point(598, 195)
        Me.txtPrice3.Name = "txtPrice3"
        Me.txtPrice3.ReadOnly = True
        Me.txtPrice3.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice3.TabIndex = 186
        Me.txtPrice3.Visible = False
        '
        'lblPrice3
        '
        Me.lblPrice3.AutoSize = True
        Me.lblPrice3.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice3.ForeColor = System.Drawing.Color.White
        Me.lblPrice3.Location = New System.Drawing.Point(540, 197)
        Me.lblPrice3.Name = "lblPrice3"
        Me.lblPrice3.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice3.TabIndex = 185
        Me.lblPrice3.Text = "Price: "
        Me.lblPrice3.Visible = False
        '
        'cmbService3
        '
        Me.cmbService3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemService3, "tblServices.Services", True))
        Me.cmbService3.DataSource = Me.TblServicesBindingSource6
        Me.cmbService3.DisplayMember = "Services"
        Me.cmbService3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbService3.FormattingEnabled = True
        Me.cmbService3.Location = New System.Drawing.Point(368, 197)
        Me.cmbService3.Name = "cmbService3"
        Me.cmbService3.Size = New System.Drawing.Size(157, 24)
        Me.cmbService3.TabIndex = 184
        Me.cmbService3.ValueMember = "Services"
        Me.cmbService3.Visible = False
        '
        'TouchSalonSystemService3
        '
        Me.TouchSalonSystemService3.DataSetName = "TouchSalonSystemService3"
        Me.TouchSalonSystemService3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblServicesBindingSource6
        '
        Me.TblServicesBindingSource6.DataMember = "tblServices"
        Me.TblServicesBindingSource6.DataSource = Me.TouchSalonSystemService3
        '
        'lblService3
        '
        Me.lblService3.AutoSize = True
        Me.lblService3.BackColor = System.Drawing.Color.Transparent
        Me.lblService3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService3.ForeColor = System.Drawing.Color.White
        Me.lblService3.Location = New System.Drawing.Point(290, 201)
        Me.lblService3.Name = "lblService3"
        Me.lblService3.Size = New System.Drawing.Size(69, 20)
        Me.lblService3.TabIndex = 183
        Me.lblService3.Text = "Service: "
        Me.lblService3.Visible = False
        '
        'cmbCategory3
        '
        Me.cmbCategory3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblServicesBindingSource2, "Category", True))
        Me.cmbCategory3.DataSource = Me.TblServicesBindingSource2
        Me.cmbCategory3.DisplayMember = "Category"
        Me.cmbCategory3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory3.FormattingEnabled = True
        Me.cmbCategory3.Location = New System.Drawing.Point(115, 199)
        Me.cmbCategory3.Name = "cmbCategory3"
        Me.cmbCategory3.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory3.TabIndex = 182
        Me.cmbCategory3.ValueMember = "Category"
        Me.cmbCategory3.Visible = False
        '
        'TblServicesBindingSource2
        '
        Me.TblServicesBindingSource2.DataMember = "tblServices"
        Me.TblServicesBindingSource2.DataSource = Me.TouchSalonSystemCategory_3
        '
        'TouchSalonSystemCategory_3
        '
        Me.TouchSalonSystemCategory_3.DataSetName = "TouchSalonSystemCategory_3"
        Me.TouchSalonSystemCategory_3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblCategory3
        '
        Me.lblCategory3.AutoSize = True
        Me.lblCategory3.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory3.ForeColor = System.Drawing.Color.White
        Me.lblCategory3.Location = New System.Drawing.Point(9, 201)
        Me.lblCategory3.Name = "lblCategory3"
        Me.lblCategory3.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory3.TabIndex = 181
        Me.lblCategory3.Text = "Category: "
        Me.lblCategory3.Visible = False
        '
        'txtPrice4
        '
        Me.txtPrice4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice4.Location = New System.Drawing.Point(601, 254)
        Me.txtPrice4.Name = "txtPrice4"
        Me.txtPrice4.ReadOnly = True
        Me.txtPrice4.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice4.TabIndex = 193
        Me.txtPrice4.Visible = False
        '
        'lblPrice4
        '
        Me.lblPrice4.AutoSize = True
        Me.lblPrice4.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice4.ForeColor = System.Drawing.Color.White
        Me.lblPrice4.Location = New System.Drawing.Point(543, 256)
        Me.lblPrice4.Name = "lblPrice4"
        Me.lblPrice4.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice4.TabIndex = 192
        Me.lblPrice4.Text = "Price: "
        Me.lblPrice4.Visible = False
        '
        'cmbService4
        '
        Me.cmbService4.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemService4, "tblServices.Services", True))
        Me.cmbService4.DataSource = Me.TblServicesBindingSource7
        Me.cmbService4.DisplayMember = "Services"
        Me.cmbService4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbService4.FormattingEnabled = True
        Me.cmbService4.Location = New System.Drawing.Point(371, 256)
        Me.cmbService4.Name = "cmbService4"
        Me.cmbService4.Size = New System.Drawing.Size(157, 24)
        Me.cmbService4.TabIndex = 191
        Me.cmbService4.ValueMember = "Services"
        Me.cmbService4.Visible = False
        '
        'TouchSalonSystemService4
        '
        Me.TouchSalonSystemService4.DataSetName = "TouchSalonSystemService4"
        Me.TouchSalonSystemService4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblServicesBindingSource7
        '
        Me.TblServicesBindingSource7.DataMember = "tblServices"
        Me.TblServicesBindingSource7.DataSource = Me.TouchSalonSystemService4
        '
        'lblService4
        '
        Me.lblService4.AutoSize = True
        Me.lblService4.BackColor = System.Drawing.Color.Transparent
        Me.lblService4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService4.ForeColor = System.Drawing.Color.White
        Me.lblService4.Location = New System.Drawing.Point(293, 260)
        Me.lblService4.Name = "lblService4"
        Me.lblService4.Size = New System.Drawing.Size(69, 20)
        Me.lblService4.TabIndex = 190
        Me.lblService4.Text = "Service: "
        Me.lblService4.Visible = False
        '
        'cmbCategory4
        '
        Me.cmbCategory4.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblServicesBindingSource3, "Category", True))
        Me.cmbCategory4.DataSource = Me.TblServicesBindingSource3
        Me.cmbCategory4.DisplayMember = "Category"
        Me.cmbCategory4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory4.FormattingEnabled = True
        Me.cmbCategory4.Location = New System.Drawing.Point(118, 258)
        Me.cmbCategory4.Name = "cmbCategory4"
        Me.cmbCategory4.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory4.TabIndex = 189
        Me.cmbCategory4.ValueMember = "Category"
        Me.cmbCategory4.Visible = False
        '
        'TblServicesBindingSource3
        '
        Me.TblServicesBindingSource3.DataMember = "tblServices"
        Me.TblServicesBindingSource3.DataSource = Me.TouchSalonSystemCategory_4
        '
        'TouchSalonSystemCategory_4
        '
        Me.TouchSalonSystemCategory_4.DataSetName = "TouchSalonSystemCategory_4"
        Me.TouchSalonSystemCategory_4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblCategory4
        '
        Me.lblCategory4.AutoSize = True
        Me.lblCategory4.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory4.ForeColor = System.Drawing.Color.White
        Me.lblCategory4.Location = New System.Drawing.Point(12, 260)
        Me.lblCategory4.Name = "lblCategory4"
        Me.lblCategory4.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory4.TabIndex = 188
        Me.lblCategory4.Text = "Category: "
        Me.lblCategory4.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(493, 351)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 20)
        Me.Label11.TabIndex = 197
        Me.Label11.Text = "Total:"
        '
        'txtAllTotal
        '
        Me.txtAllTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAllTotal.Location = New System.Drawing.Point(600, 347)
        Me.txtAllTotal.Name = "txtAllTotal"
        Me.txtAllTotal.ReadOnly = True
        Me.txtAllTotal.Size = New System.Drawing.Size(115, 24)
        Me.txtAllTotal.TabIndex = 196
        '
        'btnOrder5
        '
        Me.btnOrder5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnOrder5.FlatAppearance.BorderSize = 2
        Me.btnOrder5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnOrder5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnOrder5.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder5.ForeColor = System.Drawing.Color.DarkRed
        Me.btnOrder5.Location = New System.Drawing.Point(760, 344)
        Me.btnOrder5.Name = "btnOrder5"
        Me.btnOrder5.Size = New System.Drawing.Size(114, 30)
        Me.btnOrder5.TabIndex = 195
        Me.btnOrder5.Text = "Get Service"
        Me.btnOrder5.UseVisualStyleBackColor = True
        '
        'TblServicesTableAdapter1
        '
        Me.TblServicesTableAdapter1.ClearBeforeFill = True
        '
        'TblServicesTableAdapter
        '
        Me.TblServicesTableAdapter.ClearBeforeFill = True
        '
        'TblServicesTableAdapter2
        '
        Me.TblServicesTableAdapter2.ClearBeforeFill = True
        '
        'TblServicesTableAdapter3
        '
        Me.TblServicesTableAdapter3.ClearBeforeFill = True
        '
        'TblServicesTableAdapter4
        '
        Me.TblServicesTableAdapter4.ClearBeforeFill = True
        '
        'TblServicesTableAdapter5
        '
        Me.TblServicesTableAdapter5.ClearBeforeFill = True
        '
        'TblServicesTableAdapter6
        '
        Me.TblServicesTableAdapter6.ClearBeforeFill = True
        '
        'TblServicesTableAdapter7
        '
        Me.TblServicesTableAdapter7.ClearBeforeFill = True
        '
        'frmService
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(906, 436)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtAllTotal)
        Me.Controls.Add(Me.btnOrder5)
        Me.Controls.Add(Me.txtPrice4)
        Me.Controls.Add(Me.lblPrice4)
        Me.Controls.Add(Me.cmbService4)
        Me.Controls.Add(Me.lblService4)
        Me.Controls.Add(Me.cmbCategory4)
        Me.Controls.Add(Me.lblCategory4)
        Me.Controls.Add(Me.btnAdd3)
        Me.Controls.Add(Me.txtPrice3)
        Me.Controls.Add(Me.lblPrice3)
        Me.Controls.Add(Me.cmbService3)
        Me.Controls.Add(Me.lblService3)
        Me.Controls.Add(Me.cmbCategory3)
        Me.Controls.Add(Me.lblCategory3)
        Me.Controls.Add(Me.btnAdd2)
        Me.Controls.Add(Me.txtPrice2)
        Me.Controls.Add(Me.lblPrice2)
        Me.Controls.Add(Me.cmbService2)
        Me.Controls.Add(Me.lblService2)
        Me.Controls.Add(Me.cmbCategory2)
        Me.Controls.Add(Me.lblCategory2)
        Me.Controls.Add(Me.btnAdd1)
        Me.Controls.Add(Me.txtPrice1)
        Me.Controls.Add(Me.lblPrice1)
        Me.Controls.Add(Me.cmbService1)
        Me.Controls.Add(Me.lblService1)
        Me.Controls.Add(Me.cmbCategory1)
        Me.Controls.Add(Me.lblCategory1)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmService"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Touch Salon System: Service"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.TblServicesBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemService1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory_11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemService2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemService3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemService4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicesBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory_4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCustomerName1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCustomerName As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnAdd1 As System.Windows.Forms.Button
    Friend WithEvents txtPrice1 As System.Windows.Forms.TextBox
    Friend WithEvents lblPrice1 As System.Windows.Forms.Label
    Friend WithEvents cmbService1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblService1 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblCategory1 As System.Windows.Forms.Label
    Friend WithEvents btnAdd2 As System.Windows.Forms.Button
    Friend WithEvents txtPrice2 As System.Windows.Forms.TextBox
    Friend WithEvents lblPrice2 As System.Windows.Forms.Label
    Friend WithEvents cmbService2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblService2 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblCategory2 As System.Windows.Forms.Label
    Friend WithEvents btnAdd3 As System.Windows.Forms.Button
    Friend WithEvents txtPrice3 As System.Windows.Forms.TextBox
    Friend WithEvents lblPrice3 As System.Windows.Forms.Label
    Friend WithEvents cmbService3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblService3 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblCategory3 As System.Windows.Forms.Label
    Friend WithEvents txtPrice4 As System.Windows.Forms.TextBox
    Friend WithEvents lblPrice4 As System.Windows.Forms.Label
    Friend WithEvents cmbService4 As System.Windows.Forms.ComboBox
    Friend WithEvents lblService4 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory4 As System.Windows.Forms.ComboBox
    Friend WithEvents lblCategory4 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtAllTotal As System.Windows.Forms.TextBox
    Friend WithEvents btnOrder5 As System.Windows.Forms.Button
    Friend WithEvents TouchSalonSystemCategory_2 As TouchSuiteSalon.TouchSalonSystemCategory_2
    Friend WithEvents TblServicesBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter1 As TouchSuiteSalon.TouchSalonSystemCategory_2TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemCategory_11 As TouchSuiteSalon.TouchSalonSystemCategory_11
    Friend WithEvents TblServicesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter As TouchSuiteSalon.TouchSalonSystemCategory_11TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemCategory_3 As TouchSuiteSalon.TouchSalonSystemCategory_3
    Friend WithEvents TblServicesBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter2 As TouchSuiteSalon.TouchSalonSystemCategory_3TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemCategory_4 As TouchSuiteSalon.TouchSalonSystemCategory_4
    Friend WithEvents TblServicesBindingSource3 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter3 As TouchSuiteSalon.TouchSalonSystemCategory_4TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemService1 As TouchSuiteSalon.TouchSalonSystemService1
    Friend WithEvents TblServicesBindingSource4 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter4 As TouchSuiteSalon.TouchSalonSystemService1TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemService2 As TouchSuiteSalon.TouchSalonSystemService2
    Friend WithEvents TblServicesBindingSource5 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter5 As TouchSuiteSalon.TouchSalonSystemService2TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemService3 As TouchSuiteSalon.TouchSalonSystemService3
    Friend WithEvents TblServicesBindingSource6 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter6 As TouchSuiteSalon.TouchSalonSystemService3TableAdapters.tblServicesTableAdapter
    Friend WithEvents TouchSalonSystemService4 As TouchSuiteSalon.TouchSalonSystemService4
    Friend WithEvents TblServicesBindingSource7 As System.Windows.Forms.BindingSource
    Friend WithEvents TblServicesTableAdapter7 As TouchSuiteSalon.TouchSalonSystemService4TableAdapters.tblServicesTableAdapter
End Class
