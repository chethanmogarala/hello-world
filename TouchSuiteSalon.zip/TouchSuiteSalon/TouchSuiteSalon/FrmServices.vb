﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.IO
Imports System.Drawing
Imports MySql.Data.MySqlClient
Public Class FrmServices

    Private Sub FrmServices_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("SELECT TOP 1 * from tblServicesImage order by ID DESC", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox1.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox1.Show()



            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
   

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        frmService.Show()

    End Sub
End Class