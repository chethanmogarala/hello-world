﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmCashierStaff

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub frmCashierStaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblEmployee", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblEmployee")
            DataGridView1.DataSource = ds.Tables("tblEmployee")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        DataGridView1.Refresh()
    End Sub

    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        txtStaffID.Text = DataGridView1.Item(0, i).Value
        txtName.Text = DataGridView1.Item(1, i).Value
        cboGender.Text = DataGridView1.Item(2, i).Value
        txtAge.Text = DataGridView1.Item(3, i).Value
        txtAddress.Text = DataGridView1.Item(4, i).Value
        txtContact.Text = DataGridView1.Item(5, i).Value
        txtEmail.Text = DataGridView1.Item(6, i).Value
        txtPosition.Text = DataGridView1.Item(7, i).Value
    End Sub
End Class