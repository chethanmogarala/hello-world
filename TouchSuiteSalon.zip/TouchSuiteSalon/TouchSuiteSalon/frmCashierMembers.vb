﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmCashierMembers

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Search Student Info
        conn = GetConnect()
        Try
            conn.Open()
            cmd = New MySqlCommand("Select * from tblCustomerInfo  where MembersID = '" & txtCustomerID.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    txtCustomerID.Text = read("MembersID".ToString)
                    txtFirstName.Text = read("FullName".ToString)
                    cmbGender.Text = read("Gender".ToString)
                    DateTimePicker1.Text = read("Birthday".ToString)
                    txtAge.Text = read("Age".ToString)
                    txtAddress.Text = read("Street".ToString)
                    txtSubdivision.Text = read("Subdivision".ToString)
                    txtCity.Text = read("City".ToString)
                    txtContact.Text = read("ContactNo".ToString)
                    txtEmailAdd.Text = read("EmailAddress".ToString)
                    DateTimePicker2.Text = read("Membership".ToString)


                End While

            ElseIf txtCustomerID.Text = "" Then

                MsgBox("Insert Customer ID!")
                txtCustomerID.ReadOnly = False

                txtCustomerID.Focus()
            Else
                MsgBox("No Rows Selected!")

                txtCustomerID.Focus()
            End If



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub frmCashierMembers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        lblTime.Text = TimeOfDay
        lblTime.Text = Format(Now, "HH:mm:ss")


        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblCustomerInfo", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblCustomerInfo")
            DataGridView1.DataSource = ds.Tables("tblCustomerInfo")
            '---------------------------------------------------------



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        txtCustomerID.Text = DataGridView1.Item(0, i).Value
        txtFirstName.Text = DataGridView1.Item(1, i).Value
        cmbGender.Text = DataGridView1.Item(2, i).Value
        DateTimePicker1.Text = DataGridView1.Item(3, i).Value
        txtAge.Text = DataGridView1.Item(4, i).Value
        txtAddress.Text = DataGridView1.Item(5, i).Value
        txtSubdivision.Text = DataGridView1.Item(6, i).Value
        txtCity.Text = DataGridView1.Item(7, i).Value
        txtContact.Text = DataGridView1.Item(8, i).Value
        txtEmailAdd.Text = DataGridView1.Item(9, i).Value
        DateTimePicker2.Text = DataGridView1.Item(10, i).Value

        conn = GetConnect()

    End Sub
End Class