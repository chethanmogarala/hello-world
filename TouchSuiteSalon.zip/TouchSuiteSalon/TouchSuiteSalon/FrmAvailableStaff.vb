﻿Public Class FrmAvailableStaff

    Private Sub FrmAvailableStaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TouchSalonSystemDataSet1.tblStaffAccess' table. You can move, or remove it, as needed.
        Me.TblStaffAccessTableAdapter.Fill(Me.TouchSalonSystemDataSet1.tblStaffAccess)

    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Me.Close()
        FrmGuestMenu.Show()

    End Sub
End Class