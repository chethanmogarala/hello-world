﻿Public Class FrmServiceReport

    Private Sub FrmServiceReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'TODO: This line of code loads data into the 'TouchSalonSystemServiceBilling.tblServiceBilling' table. You can move, or remove it, as needed.
        'Me.tblServiceBillingTableAdapter.Fill(Me.TouchSalonSystemServiceBilling.tblServiceBilling, txtCustomerID.Text)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class