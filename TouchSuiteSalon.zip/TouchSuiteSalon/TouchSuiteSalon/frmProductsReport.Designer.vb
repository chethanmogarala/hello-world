﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProductsReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProductsReport))
        Me.tblPricesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemDataSet4 = New TouchSuiteSalon.TouchSalonSystemDataSet4()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.tblPricesTableAdapter = New TouchSuiteSalon.TouchSalonSystemDataSet4TableAdapters.tblPricesTableAdapter()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.tblPricesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tblPricesBindingSource
        '
        Me.tblPricesBindingSource.DataMember = "tblPrices"
        Me.tblPricesBindingSource.DataSource = Me.TouchSalonSystemDataSet4
        '
        'TouchSalonSystemDataSet4
        '
        Me.TouchSalonSystemDataSet4.DataSetName = "TouchSalonSystemDataSet4"
        Me.TouchSalonSystemDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReportViewer1
        '
        Me.ReportViewer1.BackColor = System.Drawing.Color.SkyBlue
        ReportDataSource1.Name = "DSProductReport"
        ReportDataSource1.Value = Me.tblPricesBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "TouchSuiteSalon.Report3.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(12, 51)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(653, 557)
        Me.ReportViewer1.TabIndex = 1
        '
        'tblPricesTableAdapter
        '
        Me.tblPricesTableAdapter.ClearBeforeFill = True
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.BackgroundImage = CType(resources.GetObject("btnClose.BackgroundImage"), System.Drawing.Image)
        Me.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnClose.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnClose.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnClose.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnClose.Location = New System.Drawing.Point(541, 614)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(109, 42)
        Me.btnClose.TabIndex = 102
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnClose.UseCompatibleTextRendering = True
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'frmProductsReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(679, 668)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmProductsReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Touch Salon System Products Report"
        CType(Me.tblPricesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents tblPricesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TouchSalonSystemDataSet4 As TouchSuiteSalon.TouchSalonSystemDataSet4
    Friend WithEvents tblPricesTableAdapter As TouchSuiteSalon.TouchSalonSystemDataSet4TableAdapters.tblPricesTableAdapter
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
