﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmAddCustomer

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub frmAddCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select EmployeeID, Name from tblEmployee", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblEmployee")
            DataGridView1.DataSource = ds.Tables("tblEmployee")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        txtEmployeeID.Text = DataGridView1.Item(0, i).Value

        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("Select * from tblStaffCustomer  where StaffID = '" & txtEmployeeID.Text & "'", conn)
            da1 = New MySqlDataAdapter(cmd)
            ds1.Clear()
            da1.Fill(ds1, "tblStaffCustomer")
            DataGridView2.DataSource = ds1.Tables("tblStaffCustomer")
            '---------------------------------------------------------
            conn.Close()
            DataGridView2.Refresh()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub DataGridView2_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView2.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView2.CurrentRow.Index

        txtID.Text = DataGridView2.Item(0, i).Value
        txtEmployeeID.Text = DataGridView2.Item(1, i).Value
        txtCustomer.Text = DataGridView2.Item(2, i).Value
        txtLevel.Text = DataGridView2.Item(3, i).Value
        lblDate.Text = DataGridView2.Item(4, i).Value

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        conn = GetConnect()


        Try
            conn.Open()
            str = "Insert into tblStaffCustomer values ('" & txtEmployeeID.Text & "','" & txtCustomer.Text & "','" & txtLevel.Text & "', '" & lblDate.Text & "')"

            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
        txtEmployeeID.Text = ""
        txtCustomer.Text = ""
        txtLevel.Text = ""
      

        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblStaffCustomer", conn)
            da1 = New MySqlDataAdapter(cmd)
            ds1.Clear()
            da1.Fill(ds, "tblStaffCustomer")
            DataGridView2.DataSource = ds1.Tables("tblStaffCustomer")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        DataGridView2.Refresh()

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub


    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        conn = GetConnect()
        txtEmployeeID.Enabled = False
        txtID.Enabled = False
        txtName.Enabled = False
        Try
            conn.Open()
            str = "Update tblStaffCustomer set Status = '" & txtLevel.Text & "' where StaffID = '" & txtID.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            conn.Close()
            'conn.Close()
            MsgBox("Record Updated Successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblStaffCustomer", conn)
            da1 = New MySqlDataAdapter(cmd)
            ds1.Clear()
            da1.Fill(ds1, "tblStaffCustomer")
            DataGridView2.DataSource = ds1.Tables("tblStaffCustomer")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        DataGridView2.Refresh()
    End Sub
End Class