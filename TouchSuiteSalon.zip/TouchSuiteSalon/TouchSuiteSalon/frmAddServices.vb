﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmAddServices

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtService.Text = "" Then
            MsgBox("Please enter Service")
            txtService.Focus()

        ElseIf txtPrice.Text = "" Then
            MsgBox("Please enter Service Price")
            txtPrice.Focus()

        Else

            conn = GetConnect()
            Try
                conn.Open()
                str = "Insert into tblServices values ('','" & txtService.Text & "', '" & cmbCategory.Text & "', '" & txtPrice.Text & "')"
                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Saved Successfully!")
                clear()
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try

            Try
                ' ORIG ------------------------------------------------------------
                conn.Open()
                '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
                cmd = New MySqlCommand("select * from tblServices", conn)
                da = New MySqlDataAdapter(cmd)
                ds.Clear()
                da.Fill(ds, "tblServices")
                DataGridView1.DataSource = ds.Tables("tblServices")
                '---------------------------------------------------------
                conn.Close()


            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            DataGridView1.Refresh()
        End If
    End Sub

    Public Sub clear()
        txtServiceID.Text = ""
        txtService.Text = ""
        cmbCategory.Text = ""
        txtPrice.Text = ""

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub AddProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblServices", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblServices")
            DataGridView1.DataSource = ds.Tables("tblServices")
            '---------------------------------------------------------



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Update tblServices set Category= '" & cmbCategory.Text & "', Services =  '" & txtService.Text & "', Price = '" & txtPrice.Text & "'  where ID = '" & txtServiceID.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            'conn.Close()
            MsgBox("Record Updated Successfully!")
            clear()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblServices", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblServices")
            DataGridView1.DataSource = ds.Tables("tblServices")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        DataGridView1.Refresh()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        'Delete
        Dim i As Integer
        i = MsgBox("Are you sure you want to delete the record?", vbYesNo, "Touch Suite Salon")
        If i = vbYes Then
            conn = GetConnect()
            Try
                conn.Open()
                str = "Delete from tblServices where ID = '" & txtServiceID.Text & "'"
                cmd = New MySqlCommand(str, conn)

                cmd.ExecuteNonQuery()
                conn.Close()

                clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            conn.Close()
            Try
                ' ORIG ------------------------------------------------------------
                conn.Open()
                '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
                cmd = New MySqlCommand("select * from tblServices", conn)
                da = New MySqlDataAdapter(cmd)
                ds.Clear()
                da.Fill(ds, "tblServices")
                DataGridView1.DataSource = ds.Tables("tblServices")
                '---------------------------------------------------------
                conn.Close()


            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            DataGridView1.Refresh()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        clear()

    End Sub

    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        txtServiceID.Text = DataGridView1.Item(0, i).Value
        txtService.Text = DataGridView1.Item(1, i).Value
        cmbCategory.Text = DataGridView1.Item(2, i).Value
        txtPrice.Text = DataGridView1.Item(3, i).Value

       
    End Sub
End Class