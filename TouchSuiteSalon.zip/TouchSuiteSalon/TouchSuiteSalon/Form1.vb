﻿Public Class Form1

    Private Sub btnClients_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClients.Click
        frmClientSearch.Show()

    End Sub

 

    Private Sub btnAboutUS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAboutUS.Click
        frmProductsAdmin.Show()

    End Sub

  

    Private Sub btnReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReports.Click
   
        frmReports.Show()

    End Sub

    Private Sub btnProducts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProducts.Click
        frmProductsAdmin.Show()


    End Sub



    Private Sub btnServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnServices.Click
        frmStaffMenu.Show()

    End Sub

 
    Private Sub ExpiredToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        frmExpired.Show()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        frmAboutUs.Show()
    End Sub

    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()

    End Sub

    Private Sub CommentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        frmAdminComments.Show()

    End Sub

    Private Sub CloseToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub ExpiredToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExpiredToolStripMenuItem.Click
        frmExpired.Show()
    End Sub

    Private Sub CommentsToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommentsToolStripMenuItem.Click
        frmAdminComments.Show()


    End Sub

    Private Sub ReportsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportsToolStripMenuItem.Click
        frmReports.Show()

    End Sub

    Private Sub QueueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QueueToolStripMenuItem.Click

    End Sub

    Private Sub StaffsAvailabilityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StaffsAvailabilityToolStripMenuItem.Click
        frmAddCustomer.Show()

    End Sub
End Class
