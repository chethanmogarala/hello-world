﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmAddUser


    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        conn = GetConnect()
        'Save

        Try
            Dim v As String
            v = txtPassword2.Text
            If v = txtPassword.Text Then
                conn.Open()
                str = "Insert into tblStaffAccess values ('" & txtName.Text & "','" & txtPassword.Text & "','" & txtLevel.Text & "','" & txtStatus.Text & "')"

                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Saved Successfully!")

                conn.Close()
            Else
                MsgBox("Password don't match!")

                txtPassword.Text = ""
                txtPassword2.Text = ""
                txtLevel.Text = ""
                txtPassword.Focus()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

        txtName.Text = ""
        txtPassword.Text = ""
        txtPassword2.Text = ""
        txtLevel.Text = ""
       
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class