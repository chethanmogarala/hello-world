﻿Imports System.IO
Imports System.Drawing
Imports System.Data
Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Module Module1
    Public dr As MySqlDataReader
    Public dr2 As MySqlDataReader
    Public str As String
    Public str2 As String
    Public dr3 As MySqlDataReader
    Public st3 As String
    Public str3 As String
    Public conn As MySqlConnection
    Public cmd As MySqlCommand
    Public cmd2 As MySqlCommand
    Public cmd3 As MySqlCommand
    Dim adptr As MySqlDataAdapter
    Public idno As Integer = 0 'picture
    Public img As System.Drawing.Image
    Public da As New MySqlDataAdapter
    Public ds As New DataSet
    Public dt As DataTable
    Public dv As DataView
    Public da1 As New MySqlDataAdapter
    Public ds1 As New DataSet
    Public dt1 As DataTable
    Public dv1 As DataView


    Public Function GetConnect()
        Dim DatabaseName As String = "Chethan"
        Dim server As String = "localhost"
        Dim userName As String = "root"
        Dim password As String = "BPMS"
        If Not conn Is Nothing Then conn.Close()
        'conn.ConnectionString = String.Format("server={0}; user id={1}; password={2}; database={3}; pooling=false", server, userName, password, DatabaseName)
        conn = New MySqlConnection("DATABASE=chethan;SERVER=localhost;user id=root;password=Ch@r1ie5817;port=3306;charset=utf8;MAX POOL SIZE=100000;")
        ' conn = New SqlConnection("Server = LICENSEDUSER-PC;" & "initial Catalog = TouchSalonSystem;" & " Trusted_Connection=yes")
        Return conn
    End Function


    Public Enum FormState
        adStateAddMode = 0
        adStateEditMode = 1
    End Enum
End Module

