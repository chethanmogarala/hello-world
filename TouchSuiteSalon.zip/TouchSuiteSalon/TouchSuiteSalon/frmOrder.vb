﻿Imports MySql.Data.MySqlClient
Public Class frmOrder

    Private Sub frmOrder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        conn = GetConnect()
        Try
            conn.Open()
            cmd = New MySqlCommand("Select MembersID, FullName from tblCustomerInfo where MembersID = '" & frmOrderLogin.txtMemberID.Text & "'", conn)

            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    lblCustomerName1.Text = read("MembersID".ToString)
                    lblCustomerName.Text = read("FullName".ToString)
                    ' lblUserName.Text = read("UserName".ToString)
                End While
            Else
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



        cmbProduct1.Text = ""
        cmbProduct2.Text = ""
        cmbProduct3.Text = ""
        cmbProduct4.Text = ""
        cmbProduct5.Text = ""

        txtPrice1.Text = ""
        txtPrice2.Text = ""
        txtPrice3.Text = ""
        txtPrice4.Text = ""
        txtPrice5.Text = ""

        txtTotal1.Text = ""
        txtTotal2.Text = ""
        txtTotal3.Text = ""
        txtTotal4.Text = ""
        txtTotal5.Text = ""

        cmbProduct1.Enabled = False
        cmbProduct2.Enabled = False
        cmbProduct3.Enabled = False
        cmbProduct4.Enabled = False
        cmbProduct5.Enabled = False


        txtTotal1.Text = "0.00"
        txtTotal2.Text = "0.00"
        txtTotal3.Text = "0.00"
        txtTotal4.Text = "0.00"
        txtTotal5.Text = "0.00"

        lblDate.Text = Format(Now, "MMMM dd, yyyy")
    End Sub
    Private Sub cmbCategory1_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory1.DropDown
        'Refresh()
         Me.TblPricesTableAdapter.Fill(Me.TouchSalonSystemCategory1.tblPrices)
        cmbProduct1.Enabled = True


    End Sub
    Private Sub cmbCategory1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory1.SelectedIndexChanged
        Refresh()
        Dim price As Integer
        Me.TblPricesTableAdapter1.Fill(Me.TouchSalonSystemProduct1.tblPrices, cmbCategory1.Text)

        cmbProduct1.Enabled = True
       

        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct1.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice1.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub cmbCategory2_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory2.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory2.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter2.Fill(Me.TouchSalonSystemCategory2.tblPrices)
        cmbProduct2.Enabled = True

    End Sub
    Private Sub cmbCategory2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory2.SelectedIndexChanged
       
        Refresh()
        Dim price As Integer
        'TODO: This line of code loads data into the 'TouchSalonSystemProduct2.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter3.Fill(Me.TouchSalonSystemProduct2.tblPrices, cmbCategory2.Text)

        cmbProduct2.Enabled = True


        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct2.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice2.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub cmbCategory3_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory3.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory3.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter4.Fill(Me.TouchSalonSystemCategory3.tblPrices)
        cmbProduct3.Enabled = True
    End Sub
    Private Sub cmbCategory3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory3.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemProduct3.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter5.Fill(Me.TouchSalonSystemProduct3.tblPrices, cmbCategory3.Text)
        Refresh()
        Dim price As Integer
        cmbProduct3.Enabled = True


        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct3.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice3.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub cmbCategory4_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory4.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory4.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter6.Fill(Me.TouchSalonSystemCategory4.tblPrices)
    End Sub
    Private Sub cmbCategory4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory4.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemProduct4.tblProducts' table. You can move, or remove it, as needed.
        Me.TblProductsTableAdapter.Fill(Me.TouchSalonSystemProduct4.tblProducts, cmbCategory4.Text)

        Refresh()
        Dim price As Integer
        cmbProduct4.Enabled = True


        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct4.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice4.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub cmbCategory5_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory5.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory5.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter7.Fill(Me.TouchSalonSystemCategory5.tblPrices)

    End Sub
    Private Sub cmbCategory5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory5.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemProduct5.tblPrices' table. You can move, or remove it, as needed.
        Me.TblPricesTableAdapter8.Fill(Me.TouchSalonSystemProduct5.tblPrices, cmbCategory5.Text)

        Refresh()
        Dim price As Integer
        cmbProduct5.Enabled = True


        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct5.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice5.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub cmbProduct1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbProduct1.SelectedIndexChanged
        Dim price As Integer
        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct1.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice1.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub

   

    Private Sub cmbQuantity1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbQuantity1.SelectedIndexChanged
        Dim price As Integer
        price = (txtPrice1.Text) * (cmbQuantity1.Text)
        txtTotal1.Text = Format(price, "0.00")


        Dim total As Double
        total = CDec(txtTotal1.Text) + CDec(txtTotal2.Text) + CDec(txtTotal3.Text) + CDec(txtTotal4.Text) + CDec(txtTotal5.Text)
        txtAllTotal.Text = Format(total, "0.00")
    End Sub

    Private Sub cmbProduct2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbProduct2.SelectedIndexChanged
        Dim price As Integer
        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct2.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice2.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub cmbQuantity2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbQuantity2.SelectedIndexChanged
        Dim price As Integer
        price = (txtPrice2.Text) * (cmbQuantity2.Text)
        txtTotal2.Text = Format(price, "0.00")

        Dim total As Double
        total = CDec(txtTotal1.Text) + CDec(txtTotal2.Text) + CDec(txtTotal3.Text) + CDec(txtTotal4.Text) + CDec(txtTotal5.Text)
       
        txtAllTotal.Text = Format(total, "0.00")
    End Sub

    Private Sub cmbQuantity3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbQuantity3.SelectedIndexChanged
        Dim price As Integer
        price = (txtPrice3.Text) * (cmbQuantity3.Text)
        txtTotal3.Text = Format(price, "0.00")


        Dim total As Double
        total = CDec(txtTotal1.Text) + CDec(txtTotal2.Text) + CDec(txtTotal3.Text) + CDec(txtTotal4.Text) + CDec(txtTotal5.Text)
        txtAllTotal.Text = Format(total, "0.00")
    End Sub

    Private Sub cmbQuantity4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbQuantity4.SelectedIndexChanged
        Dim price As Integer

        price = (txtPrice4.Text) * (cmbQuantity4.Text)
        txtTotal4.Text = Format(price, "0.00")

        Dim total As Double
        total = CDec(txtTotal1.Text) + CDec(txtTotal2.Text) + CDec(txtTotal3.Text) + CDec(txtTotal4.Text) + CDec(txtTotal5.Text)
        txtAllTotal.Text = Format(total, "0.00")
    End Sub

    Private Sub cmbQuantity5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbQuantity5.SelectedIndexChanged
        Dim price As Integer
        price = (txtPrice5.Text) * (cmbQuantity5.Text)
        txtTotal5.Text = Format(price, "0.00")


        Dim total As Double
        total = CDec(txtTotal1.Text) + CDec(txtTotal2.Text) + CDec(txtTotal3.Text) + CDec(txtTotal4.Text) + CDec(txtTotal5.Text)
        txtAllTotal.Text = Format(total, "0.00")
    End Sub

    Private Sub txtPrice2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPrice2.TextChanged

    End Sub

    Private Sub cmbProduct3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbProduct3.SelectedIndexChanged
        Dim price As Integer
        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct3.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice3.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cmbProduct4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbProduct4.SelectedIndexChanged
        Dim price As Integer
        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct4.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice4.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cmbProduct5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbProduct5.SelectedIndexChanged
        Dim price As Integer
        'Prices
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Prices from tblPrices  where Product = '" & cmbProduct5.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Prices".ToString)
                    txtPrice5.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtAllTotal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAllTotal.TextChanged

    End Sub

    Private Sub btnOrder5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder5.Click
        Dim i As Integer
        i = MsgBox("Is your Orders correct?", vbYesNo, "Touch Suite Salon")
        If i = vbYes Then
            conn = GetConnect()
            Try
                conn.Open()
                str = "Insert into tblProductBilling values ('" & lblCustomerName1.Text & "', '" & lblCustomerName.Text & "', '" & cmbCategory1.Text & "', '" & cmbCategory2.Text & "', '" & cmbCategory3.Text & "', '" & cmbCategory4.Text & "', '" & cmbCategory5.Text & "', '" & cmbProduct1.Text & "', '" & cmbProduct2.Text & "','" & cmbProduct3.Text & "','" & cmbProduct4.Text & "','" & cmbProduct5.Text & "', '" & txtPrice1.Text & "', '" & txtPrice2.Text & "','" & txtPrice3.Text & "','" & txtPrice4.Text & "','" & txtPrice5.Text & "','" & cmbQuantity1.Text & "','" & cmbQuantity2.Text & "','" & cmbQuantity3.Text & "','" & cmbQuantity4.Text & "','" & cmbQuantity5.Text & "','" & txtAllTotal.Text & "','" & lblDate.Text & "')"
                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Your Order is now in processed, Please GO to cashier.")

                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try


            Me.Close()

        End If
    End Sub

    Private Sub btnAdd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd1.Click
        lblCategory2.Visible = True
        cmbCategory2.Visible = True
        lblProduct2.Visible = True
        cmbProduct2.Visible = True
        lblPrice2.Visible = True
        txtPrice2.Visible = True
        lblQuantity2.Visible = True
        cmbQuantity2.Visible = True
        txtTotal2.Visible = True
        btnAdd2.Visible = True
       
    End Sub

    Private Sub btnAdd2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        lblCategory3.Visible = True
        cmbCategory3.Visible = True
        lblProduct3.Visible = True
        cmbProduct3.Visible = True
        lblPrice3.Visible = True
        txtPrice3.Visible = True
        lblQuantity3.Visible = True
        cmbQuantity3.Visible = True
        txtTotal3.Visible = True
        btnAdd3.Visible = True
      

    End Sub

    Private Sub btnAdd3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd3.Click
        lblCategory4.Visible = True
        cmbCategory4.Visible = True
        lblProduct4.Visible = True
        cmbProduct4.Visible = True
        lblPrice4.Visible = True
        txtPrice4.Visible = True
        lblQuantity4.Visible = True
        cmbQuantity4.Visible = True
        txtTotal4.Visible = True
        btnAdd4.Visible = True
      
    End Sub

    Private Sub btnAdd4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd4.Click
        lblCategory5.Visible = True
        cmbCategory5.Visible = True
        lblProduct5.Visible = True
        cmbProduct5.Visible = True
        lblPrice5.Visible = True
        txtPrice5.Visible = True
        lblQuantity5.Visible = True
        cmbQuantity5.Visible = True
        txtTotal5.Visible = True
        btnOrder5.Visible = True

    End Sub
End Class