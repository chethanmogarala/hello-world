﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrder))
        Me.lblDate = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblCategory1 = New System.Windows.Forms.Label()
        Me.lblCategory2 = New System.Windows.Forms.Label()
        Me.lblCategory3 = New System.Windows.Forms.Label()
        Me.lblCategory4 = New System.Windows.Forms.Label()
        Me.lblCategory5 = New System.Windows.Forms.Label()
        Me.cmbCategory1 = New System.Windows.Forms.ComboBox()
        Me.TblPricesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory1 = New TouchSuiteSalon.TouchSalonSystemCategory1()
        Me.cmbCategory2 = New System.Windows.Forms.ComboBox()
        Me.TblPricesBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory2 = New TouchSuiteSalon.TouchSalonSystemCategory2()
        Me.cmbCategory3 = New System.Windows.Forms.ComboBox()
        Me.TblPricesBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory3 = New TouchSuiteSalon.TouchSalonSystemCategory3()
        Me.cmbCategory4 = New System.Windows.Forms.ComboBox()
        Me.TblPricesBindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory4 = New TouchSuiteSalon.TouchSalonSystemCategory4()
        Me.cmbCategory5 = New System.Windows.Forms.ComboBox()
        Me.TblPricesBindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemCategory5 = New TouchSuiteSalon.TouchSalonSystemCategory5()
        Me.cmbProduct1 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemProduct1 = New TouchSuiteSalon.TouchSalonSystemProduct1()
        Me.TblPricesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProduct1 = New System.Windows.Forms.Label()
        Me.cmbProduct2 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemProduct2 = New TouchSuiteSalon.TouchSalonSystemProduct2()
        Me.TblPricesBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProduct2 = New System.Windows.Forms.Label()
        Me.cmbProduct3 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemProduct3 = New TouchSuiteSalon.TouchSalonSystemProduct3()
        Me.TblPricesBindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProduct3 = New System.Windows.Forms.Label()
        Me.cmbProduct4 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemProduct4 = New TouchSuiteSalon.TouchSalonSystemProduct4()
        Me.TblProductsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProduct4 = New System.Windows.Forms.Label()
        Me.cmbProduct5 = New System.Windows.Forms.ComboBox()
        Me.TouchSalonSystemProduct5 = New TouchSuiteSalon.TouchSalonSystemProduct5()
        Me.TblPricesBindingSource8 = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProduct5 = New System.Windows.Forms.Label()
        Me.lblPrice5 = New System.Windows.Forms.Label()
        Me.lblPrice4 = New System.Windows.Forms.Label()
        Me.lblPrice3 = New System.Windows.Forms.Label()
        Me.lblPrice2 = New System.Windows.Forms.Label()
        Me.lblPrice1 = New System.Windows.Forms.Label()
        Me.txtPrice1 = New System.Windows.Forms.TextBox()
        Me.txtPrice2 = New System.Windows.Forms.TextBox()
        Me.txtPrice3 = New System.Windows.Forms.TextBox()
        Me.txtPrice4 = New System.Windows.Forms.TextBox()
        Me.txtPrice5 = New System.Windows.Forms.TextBox()
        Me.cmbQuantity5 = New System.Windows.Forms.ComboBox()
        Me.lblQuantity5 = New System.Windows.Forms.Label()
        Me.cmbQuantity4 = New System.Windows.Forms.ComboBox()
        Me.lblQuantity4 = New System.Windows.Forms.Label()
        Me.cmbQuantity3 = New System.Windows.Forms.ComboBox()
        Me.lblQuantity3 = New System.Windows.Forms.Label()
        Me.cmbQuantity2 = New System.Windows.Forms.ComboBox()
        Me.lblQuantity2 = New System.Windows.Forms.Label()
        Me.cmbQuantity1 = New System.Windows.Forms.ComboBox()
        Me.lblQuantity1 = New System.Windows.Forms.Label()
        Me.txtTotal5 = New System.Windows.Forms.TextBox()
        Me.txtTotal4 = New System.Windows.Forms.TextBox()
        Me.txtTotal3 = New System.Windows.Forms.TextBox()
        Me.txtTotal2 = New System.Windows.Forms.TextBox()
        Me.txtTotal1 = New System.Windows.Forms.TextBox()
        Me.btnAdd1 = New System.Windows.Forms.Button()
        Me.btnAdd2 = New System.Windows.Forms.Button()
        Me.btnAdd3 = New System.Windows.Forms.Button()
        Me.btnAdd4 = New System.Windows.Forms.Button()
        Me.btnOrder5 = New System.Windows.Forms.Button()
        Me.TblPricesTableAdapter = New TouchSuiteSalon.TouchSalonSystemCategory1TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter1 = New TouchSuiteSalon.TouchSalonSystemProduct1TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter2 = New TouchSuiteSalon.TouchSalonSystemCategory2TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter3 = New TouchSuiteSalon.TouchSalonSystemProduct2TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter4 = New TouchSuiteSalon.TouchSalonSystemCategory3TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter5 = New TouchSuiteSalon.TouchSalonSystemProduct3TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter6 = New TouchSuiteSalon.TouchSalonSystemCategory4TableAdapters.tblPricesTableAdapter()
        Me.TblProductsTableAdapter = New TouchSuiteSalon.TouchSalonSystemProduct4TableAdapters.tblProductsTableAdapter()
        Me.TblPricesTableAdapter7 = New TouchSuiteSalon.TouchSalonSystemCategory5TableAdapters.tblPricesTableAdapter()
        Me.TblPricesTableAdapter8 = New TouchSuiteSalon.TouchSalonSystemProduct5TableAdapters.tblPricesTableAdapter()
        Me.txtAllTotal = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCustomerName1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblCustomerName = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.TblPricesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemCategory5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemProduct1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemProduct2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemProduct3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemProduct4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProductsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemProduct5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPricesBindingSource8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDate.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.White
        Me.lblDate.Location = New System.Drawing.Point(755, 19)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(0, 17)
        Me.lblDate.TabIndex = 48
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(672, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 17)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "Date: "
        '
        'lblCategory1
        '
        Me.lblCategory1.AutoSize = True
        Me.lblCategory1.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory1.ForeColor = System.Drawing.Color.White
        Me.lblCategory1.Location = New System.Drawing.Point(26, 103)
        Me.lblCategory1.Name = "lblCategory1"
        Me.lblCategory1.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory1.TabIndex = 99
        Me.lblCategory1.Text = "Category: "
        '
        'lblCategory2
        '
        Me.lblCategory2.AutoSize = True
        Me.lblCategory2.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory2.ForeColor = System.Drawing.Color.White
        Me.lblCategory2.Location = New System.Drawing.Point(26, 156)
        Me.lblCategory2.Name = "lblCategory2"
        Me.lblCategory2.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory2.TabIndex = 101
        Me.lblCategory2.Text = "Category: "
        Me.lblCategory2.Visible = False
        '
        'lblCategory3
        '
        Me.lblCategory3.AutoSize = True
        Me.lblCategory3.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory3.ForeColor = System.Drawing.Color.White
        Me.lblCategory3.Location = New System.Drawing.Point(26, 202)
        Me.lblCategory3.Name = "lblCategory3"
        Me.lblCategory3.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory3.TabIndex = 103
        Me.lblCategory3.Text = "Category: "
        Me.lblCategory3.Visible = False
        '
        'lblCategory4
        '
        Me.lblCategory4.AutoSize = True
        Me.lblCategory4.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory4.ForeColor = System.Drawing.Color.White
        Me.lblCategory4.Location = New System.Drawing.Point(26, 249)
        Me.lblCategory4.Name = "lblCategory4"
        Me.lblCategory4.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory4.TabIndex = 105
        Me.lblCategory4.Text = "Category: "
        Me.lblCategory4.Visible = False
        '
        'lblCategory5
        '
        Me.lblCategory5.AutoSize = True
        Me.lblCategory5.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory5.ForeColor = System.Drawing.Color.White
        Me.lblCategory5.Location = New System.Drawing.Point(26, 303)
        Me.lblCategory5.Name = "lblCategory5"
        Me.lblCategory5.Size = New System.Drawing.Size(81, 20)
        Me.lblCategory5.TabIndex = 107
        Me.lblCategory5.Text = "Category: "
        Me.lblCategory5.Visible = False
        '
        'cmbCategory1
        '
        Me.cmbCategory1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPricesBindingSource, "Category", True))
        Me.cmbCategory1.DataSource = Me.TblPricesBindingSource
        Me.cmbCategory1.DisplayMember = "Category"
        Me.cmbCategory1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory1.FormattingEnabled = True
        Me.cmbCategory1.Location = New System.Drawing.Point(132, 101)
        Me.cmbCategory1.Name = "cmbCategory1"
        Me.cmbCategory1.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory1.TabIndex = 108
        Me.cmbCategory1.ValueMember = "Category"
        '
        'TblPricesBindingSource
        '
        Me.TblPricesBindingSource.DataMember = "tblPrices"
        Me.TblPricesBindingSource.DataSource = Me.TouchSalonSystemCategory1
        '
        'TouchSalonSystemCategory1
        '
        Me.TouchSalonSystemCategory1.DataSetName = "TouchSalonSystemCategory1"
        Me.TouchSalonSystemCategory1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbCategory2
        '
        Me.cmbCategory2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPricesBindingSource2, "Category", True))
        Me.cmbCategory2.DataSource = Me.TblPricesBindingSource2
        Me.cmbCategory2.DisplayMember = "Category"
        Me.cmbCategory2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory2.FormattingEnabled = True
        Me.cmbCategory2.Location = New System.Drawing.Point(132, 156)
        Me.cmbCategory2.Name = "cmbCategory2"
        Me.cmbCategory2.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory2.TabIndex = 109
        Me.cmbCategory2.ValueMember = "Category"
        Me.cmbCategory2.Visible = False
        '
        'TblPricesBindingSource2
        '
        Me.TblPricesBindingSource2.DataMember = "tblPrices"
        Me.TblPricesBindingSource2.DataSource = Me.TouchSalonSystemCategory2
        '
        'TouchSalonSystemCategory2
        '
        Me.TouchSalonSystemCategory2.DataSetName = "TouchSalonSystemCategory2"
        Me.TouchSalonSystemCategory2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbCategory3
        '
        Me.cmbCategory3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPricesBindingSource4, "Category", True))
        Me.cmbCategory3.DataSource = Me.TblPricesBindingSource4
        Me.cmbCategory3.DisplayMember = "Category"
        Me.cmbCategory3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory3.FormattingEnabled = True
        Me.cmbCategory3.Location = New System.Drawing.Point(132, 202)
        Me.cmbCategory3.Name = "cmbCategory3"
        Me.cmbCategory3.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory3.TabIndex = 110
        Me.cmbCategory3.ValueMember = "Category"
        Me.cmbCategory3.Visible = False
        '
        'TblPricesBindingSource4
        '
        Me.TblPricesBindingSource4.DataMember = "tblPrices"
        Me.TblPricesBindingSource4.DataSource = Me.TouchSalonSystemCategory3
        '
        'TouchSalonSystemCategory3
        '
        Me.TouchSalonSystemCategory3.DataSetName = "TouchSalonSystemCategory3"
        Me.TouchSalonSystemCategory3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbCategory4
        '
        Me.cmbCategory4.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPricesBindingSource6, "Category", True))
        Me.cmbCategory4.DataSource = Me.TblPricesBindingSource6
        Me.cmbCategory4.DisplayMember = "Category"
        Me.cmbCategory4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory4.FormattingEnabled = True
        Me.cmbCategory4.Location = New System.Drawing.Point(132, 249)
        Me.cmbCategory4.Name = "cmbCategory4"
        Me.cmbCategory4.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory4.TabIndex = 111
        Me.cmbCategory4.ValueMember = "Category"
        Me.cmbCategory4.Visible = False
        '
        'TblPricesBindingSource6
        '
        Me.TblPricesBindingSource6.DataMember = "tblPrices"
        Me.TblPricesBindingSource6.DataSource = Me.TouchSalonSystemCategory4
        '
        'TouchSalonSystemCategory4
        '
        Me.TouchSalonSystemCategory4.DataSetName = "TouchSalonSystemCategory4"
        Me.TouchSalonSystemCategory4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbCategory5
        '
        Me.cmbCategory5.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPricesBindingSource7, "Category", True))
        Me.cmbCategory5.DataSource = Me.TblPricesBindingSource7
        Me.cmbCategory5.DisplayMember = "Category"
        Me.cmbCategory5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory5.FormattingEnabled = True
        Me.cmbCategory5.Location = New System.Drawing.Point(132, 303)
        Me.cmbCategory5.Name = "cmbCategory5"
        Me.cmbCategory5.Size = New System.Drawing.Size(157, 24)
        Me.cmbCategory5.TabIndex = 112
        Me.cmbCategory5.ValueMember = "Category"
        Me.cmbCategory5.Visible = False
        '
        'TblPricesBindingSource7
        '
        Me.TblPricesBindingSource7.DataMember = "tblPrices"
        Me.TblPricesBindingSource7.DataSource = Me.TouchSalonSystemCategory5
        '
        'TouchSalonSystemCategory5
        '
        Me.TouchSalonSystemCategory5.DataSetName = "TouchSalonSystemCategory5"
        Me.TouchSalonSystemCategory5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbProduct1
        '
        Me.cmbProduct1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemProduct1, "tblPrices.Product", True))
        Me.cmbProduct1.DataSource = Me.TblPricesBindingSource1
        Me.cmbProduct1.DisplayMember = "Product"
        Me.cmbProduct1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProduct1.FormattingEnabled = True
        Me.cmbProduct1.Location = New System.Drawing.Point(385, 99)
        Me.cmbProduct1.Name = "cmbProduct1"
        Me.cmbProduct1.Size = New System.Drawing.Size(157, 24)
        Me.cmbProduct1.TabIndex = 114
        Me.cmbProduct1.ValueMember = "Product"
        '
        'TouchSalonSystemProduct1
        '
        Me.TouchSalonSystemProduct1.DataSetName = "TouchSalonSystemProduct1"
        Me.TouchSalonSystemProduct1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblPricesBindingSource1
        '
        Me.TblPricesBindingSource1.DataMember = "tblPrices"
        Me.TblPricesBindingSource1.DataSource = Me.TouchSalonSystemProduct1
        '
        'lblProduct1
        '
        Me.lblProduct1.AutoSize = True
        Me.lblProduct1.BackColor = System.Drawing.Color.Transparent
        Me.lblProduct1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct1.ForeColor = System.Drawing.Color.White
        Me.lblProduct1.Location = New System.Drawing.Point(307, 103)
        Me.lblProduct1.Name = "lblProduct1"
        Me.lblProduct1.Size = New System.Drawing.Size(72, 20)
        Me.lblProduct1.TabIndex = 113
        Me.lblProduct1.Text = "Product: "
        '
        'cmbProduct2
        '
        Me.cmbProduct2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemProduct2, "tblPrices.Product", True))
        Me.cmbProduct2.DataSource = Me.TblPricesBindingSource3
        Me.cmbProduct2.DisplayMember = "Product"
        Me.cmbProduct2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProduct2.FormattingEnabled = True
        Me.cmbProduct2.Location = New System.Drawing.Point(385, 154)
        Me.cmbProduct2.Name = "cmbProduct2"
        Me.cmbProduct2.Size = New System.Drawing.Size(157, 24)
        Me.cmbProduct2.TabIndex = 116
        Me.cmbProduct2.ValueMember = "Product"
        Me.cmbProduct2.Visible = False
        '
        'TouchSalonSystemProduct2
        '
        Me.TouchSalonSystemProduct2.DataSetName = "TouchSalonSystemProduct2"
        Me.TouchSalonSystemProduct2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblPricesBindingSource3
        '
        Me.TblPricesBindingSource3.DataMember = "tblPrices"
        Me.TblPricesBindingSource3.DataSource = Me.TouchSalonSystemProduct2
        '
        'lblProduct2
        '
        Me.lblProduct2.AutoSize = True
        Me.lblProduct2.BackColor = System.Drawing.Color.Transparent
        Me.lblProduct2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct2.ForeColor = System.Drawing.Color.White
        Me.lblProduct2.Location = New System.Drawing.Point(307, 158)
        Me.lblProduct2.Name = "lblProduct2"
        Me.lblProduct2.Size = New System.Drawing.Size(72, 20)
        Me.lblProduct2.TabIndex = 115
        Me.lblProduct2.Text = "Product: "
        Me.lblProduct2.Visible = False
        '
        'cmbProduct3
        '
        Me.cmbProduct3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemProduct3, "tblPrices.Product", True))
        Me.cmbProduct3.DataSource = Me.TblPricesBindingSource5
        Me.cmbProduct3.DisplayMember = "Product"
        Me.cmbProduct3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProduct3.FormattingEnabled = True
        Me.cmbProduct3.Location = New System.Drawing.Point(385, 200)
        Me.cmbProduct3.Name = "cmbProduct3"
        Me.cmbProduct3.Size = New System.Drawing.Size(157, 24)
        Me.cmbProduct3.TabIndex = 118
        Me.cmbProduct3.ValueMember = "Product"
        Me.cmbProduct3.Visible = False
        '
        'TouchSalonSystemProduct3
        '
        Me.TouchSalonSystemProduct3.DataSetName = "TouchSalonSystemProduct3"
        Me.TouchSalonSystemProduct3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblPricesBindingSource5
        '
        Me.TblPricesBindingSource5.DataMember = "tblPrices"
        Me.TblPricesBindingSource5.DataSource = Me.TouchSalonSystemProduct3
        '
        'lblProduct3
        '
        Me.lblProduct3.AutoSize = True
        Me.lblProduct3.BackColor = System.Drawing.Color.Transparent
        Me.lblProduct3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct3.ForeColor = System.Drawing.Color.White
        Me.lblProduct3.Location = New System.Drawing.Point(307, 204)
        Me.lblProduct3.Name = "lblProduct3"
        Me.lblProduct3.Size = New System.Drawing.Size(72, 20)
        Me.lblProduct3.TabIndex = 117
        Me.lblProduct3.Text = "Product: "
        Me.lblProduct3.Visible = False
        '
        'cmbProduct4
        '
        Me.cmbProduct4.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemProduct4, "tblProducts.Product", True))
        Me.cmbProduct4.DataSource = Me.TblProductsBindingSource
        Me.cmbProduct4.DisplayMember = "Product"
        Me.cmbProduct4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProduct4.FormattingEnabled = True
        Me.cmbProduct4.Location = New System.Drawing.Point(385, 247)
        Me.cmbProduct4.Name = "cmbProduct4"
        Me.cmbProduct4.Size = New System.Drawing.Size(157, 24)
        Me.cmbProduct4.TabIndex = 120
        Me.cmbProduct4.ValueMember = "Product"
        Me.cmbProduct4.Visible = False
        '
        'TouchSalonSystemProduct4
        '
        Me.TouchSalonSystemProduct4.DataSetName = "TouchSalonSystemProduct4"
        Me.TouchSalonSystemProduct4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblProductsBindingSource
        '
        Me.TblProductsBindingSource.DataMember = "tblProducts"
        Me.TblProductsBindingSource.DataSource = Me.TouchSalonSystemProduct4
        '
        'lblProduct4
        '
        Me.lblProduct4.AutoSize = True
        Me.lblProduct4.BackColor = System.Drawing.Color.Transparent
        Me.lblProduct4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct4.ForeColor = System.Drawing.Color.White
        Me.lblProduct4.Location = New System.Drawing.Point(307, 251)
        Me.lblProduct4.Name = "lblProduct4"
        Me.lblProduct4.Size = New System.Drawing.Size(72, 20)
        Me.lblProduct4.TabIndex = 119
        Me.lblProduct4.Text = "Product: "
        Me.lblProduct4.Visible = False
        '
        'cmbProduct5
        '
        Me.cmbProduct5.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TouchSalonSystemProduct5, "tblPrices.Product", True))
        Me.cmbProduct5.DataSource = Me.TblPricesBindingSource8
        Me.cmbProduct5.DisplayMember = "Product"
        Me.cmbProduct5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProduct5.FormattingEnabled = True
        Me.cmbProduct5.Location = New System.Drawing.Point(385, 297)
        Me.cmbProduct5.Name = "cmbProduct5"
        Me.cmbProduct5.Size = New System.Drawing.Size(157, 24)
        Me.cmbProduct5.TabIndex = 122
        Me.cmbProduct5.ValueMember = "Product"
        Me.cmbProduct5.Visible = False
        '
        'TouchSalonSystemProduct5
        '
        Me.TouchSalonSystemProduct5.DataSetName = "TouchSalonSystemProduct5"
        Me.TouchSalonSystemProduct5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblPricesBindingSource8
        '
        Me.TblPricesBindingSource8.DataMember = "tblPrices"
        Me.TblPricesBindingSource8.DataSource = Me.TouchSalonSystemProduct5
        '
        'lblProduct5
        '
        Me.lblProduct5.AutoSize = True
        Me.lblProduct5.BackColor = System.Drawing.Color.Transparent
        Me.lblProduct5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct5.ForeColor = System.Drawing.Color.White
        Me.lblProduct5.Location = New System.Drawing.Point(307, 301)
        Me.lblProduct5.Name = "lblProduct5"
        Me.lblProduct5.Size = New System.Drawing.Size(72, 20)
        Me.lblProduct5.TabIndex = 121
        Me.lblProduct5.Text = "Product: "
        Me.lblProduct5.Visible = False
        '
        'lblPrice5
        '
        Me.lblPrice5.AutoSize = True
        Me.lblPrice5.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice5.ForeColor = System.Drawing.Color.White
        Me.lblPrice5.Location = New System.Drawing.Point(557, 297)
        Me.lblPrice5.Name = "lblPrice5"
        Me.lblPrice5.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice5.TabIndex = 127
        Me.lblPrice5.Text = "Price: "
        Me.lblPrice5.Visible = False
        '
        'lblPrice4
        '
        Me.lblPrice4.AutoSize = True
        Me.lblPrice4.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice4.ForeColor = System.Drawing.Color.White
        Me.lblPrice4.Location = New System.Drawing.Point(557, 247)
        Me.lblPrice4.Name = "lblPrice4"
        Me.lblPrice4.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice4.TabIndex = 126
        Me.lblPrice4.Text = "Price: "
        Me.lblPrice4.Visible = False
        '
        'lblPrice3
        '
        Me.lblPrice3.AutoSize = True
        Me.lblPrice3.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice3.ForeColor = System.Drawing.Color.White
        Me.lblPrice3.Location = New System.Drawing.Point(557, 200)
        Me.lblPrice3.Name = "lblPrice3"
        Me.lblPrice3.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice3.TabIndex = 125
        Me.lblPrice3.Text = "Price: "
        Me.lblPrice3.Visible = False
        '
        'lblPrice2
        '
        Me.lblPrice2.AutoSize = True
        Me.lblPrice2.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice2.ForeColor = System.Drawing.Color.White
        Me.lblPrice2.Location = New System.Drawing.Point(557, 154)
        Me.lblPrice2.Name = "lblPrice2"
        Me.lblPrice2.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice2.TabIndex = 124
        Me.lblPrice2.Text = "Price: "
        Me.lblPrice2.Visible = False
        '
        'lblPrice1
        '
        Me.lblPrice1.AutoSize = True
        Me.lblPrice1.BackColor = System.Drawing.Color.Transparent
        Me.lblPrice1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice1.ForeColor = System.Drawing.Color.White
        Me.lblPrice1.Location = New System.Drawing.Point(557, 99)
        Me.lblPrice1.Name = "lblPrice1"
        Me.lblPrice1.Size = New System.Drawing.Size(52, 20)
        Me.lblPrice1.TabIndex = 123
        Me.lblPrice1.Text = "Price: "
        '
        'txtPrice1
        '
        Me.txtPrice1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice1.Location = New System.Drawing.Point(615, 97)
        Me.txtPrice1.Name = "txtPrice1"
        Me.txtPrice1.ReadOnly = True
        Me.txtPrice1.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice1.TabIndex = 128
        '
        'txtPrice2
        '
        Me.txtPrice2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice2.Location = New System.Drawing.Point(615, 150)
        Me.txtPrice2.Name = "txtPrice2"
        Me.txtPrice2.ReadOnly = True
        Me.txtPrice2.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice2.TabIndex = 129
        Me.txtPrice2.Visible = False
        '
        'txtPrice3
        '
        Me.txtPrice3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice3.Location = New System.Drawing.Point(615, 198)
        Me.txtPrice3.Name = "txtPrice3"
        Me.txtPrice3.ReadOnly = True
        Me.txtPrice3.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice3.TabIndex = 130
        Me.txtPrice3.Visible = False
        '
        'txtPrice4
        '
        Me.txtPrice4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice4.Location = New System.Drawing.Point(615, 245)
        Me.txtPrice4.Name = "txtPrice4"
        Me.txtPrice4.ReadOnly = True
        Me.txtPrice4.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice4.TabIndex = 131
        Me.txtPrice4.Visible = False
        '
        'txtPrice5
        '
        Me.txtPrice5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice5.Location = New System.Drawing.Point(615, 293)
        Me.txtPrice5.Name = "txtPrice5"
        Me.txtPrice5.ReadOnly = True
        Me.txtPrice5.Size = New System.Drawing.Size(115, 24)
        Me.txtPrice5.TabIndex = 132
        Me.txtPrice5.Visible = False
        '
        'cmbQuantity5
        '
        Me.cmbQuantity5.AutoCompleteCustomSource.AddRange(New String() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQuantity5.FormattingEnabled = True
        Me.cmbQuantity5.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity5.Location = New System.Drawing.Point(814, 291)
        Me.cmbQuantity5.Name = "cmbQuantity5"
        Me.cmbQuantity5.Size = New System.Drawing.Size(94, 24)
        Me.cmbQuantity5.TabIndex = 142
        Me.cmbQuantity5.Visible = False
        '
        'lblQuantity5
        '
        Me.lblQuantity5.AutoSize = True
        Me.lblQuantity5.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity5.ForeColor = System.Drawing.Color.White
        Me.lblQuantity5.Location = New System.Drawing.Point(736, 295)
        Me.lblQuantity5.Name = "lblQuantity5"
        Me.lblQuantity5.Size = New System.Drawing.Size(72, 20)
        Me.lblQuantity5.TabIndex = 141
        Me.lblQuantity5.Text = "Quantity:"
        Me.lblQuantity5.Visible = False
        '
        'cmbQuantity4
        '
        Me.cmbQuantity4.AutoCompleteCustomSource.AddRange(New String() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQuantity4.FormattingEnabled = True
        Me.cmbQuantity4.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity4.Location = New System.Drawing.Point(814, 241)
        Me.cmbQuantity4.Name = "cmbQuantity4"
        Me.cmbQuantity4.Size = New System.Drawing.Size(94, 24)
        Me.cmbQuantity4.TabIndex = 140
        Me.cmbQuantity4.Visible = False
        '
        'lblQuantity4
        '
        Me.lblQuantity4.AutoSize = True
        Me.lblQuantity4.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity4.ForeColor = System.Drawing.Color.White
        Me.lblQuantity4.Location = New System.Drawing.Point(736, 245)
        Me.lblQuantity4.Name = "lblQuantity4"
        Me.lblQuantity4.Size = New System.Drawing.Size(72, 20)
        Me.lblQuantity4.TabIndex = 139
        Me.lblQuantity4.Text = "Quantity:"
        Me.lblQuantity4.Visible = False
        '
        'cmbQuantity3
        '
        Me.cmbQuantity3.AutoCompleteCustomSource.AddRange(New String() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQuantity3.FormattingEnabled = True
        Me.cmbQuantity3.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity3.Location = New System.Drawing.Point(814, 194)
        Me.cmbQuantity3.Name = "cmbQuantity3"
        Me.cmbQuantity3.Size = New System.Drawing.Size(94, 24)
        Me.cmbQuantity3.TabIndex = 138
        Me.cmbQuantity3.Visible = False
        '
        'lblQuantity3
        '
        Me.lblQuantity3.AutoSize = True
        Me.lblQuantity3.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity3.ForeColor = System.Drawing.Color.White
        Me.lblQuantity3.Location = New System.Drawing.Point(736, 198)
        Me.lblQuantity3.Name = "lblQuantity3"
        Me.lblQuantity3.Size = New System.Drawing.Size(72, 20)
        Me.lblQuantity3.TabIndex = 137
        Me.lblQuantity3.Text = "Quantity:"
        Me.lblQuantity3.Visible = False
        '
        'cmbQuantity2
        '
        Me.cmbQuantity2.AutoCompleteCustomSource.AddRange(New String() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQuantity2.FormattingEnabled = True
        Me.cmbQuantity2.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity2.Location = New System.Drawing.Point(814, 148)
        Me.cmbQuantity2.Name = "cmbQuantity2"
        Me.cmbQuantity2.Size = New System.Drawing.Size(94, 24)
        Me.cmbQuantity2.TabIndex = 136
        Me.cmbQuantity2.Visible = False
        '
        'lblQuantity2
        '
        Me.lblQuantity2.AutoSize = True
        Me.lblQuantity2.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity2.ForeColor = System.Drawing.Color.White
        Me.lblQuantity2.Location = New System.Drawing.Point(736, 152)
        Me.lblQuantity2.Name = "lblQuantity2"
        Me.lblQuantity2.Size = New System.Drawing.Size(72, 20)
        Me.lblQuantity2.TabIndex = 135
        Me.lblQuantity2.Text = "Quantity:"
        Me.lblQuantity2.Visible = False
        '
        'cmbQuantity1
        '
        Me.cmbQuantity1.AutoCompleteCustomSource.AddRange(New String() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQuantity1.FormattingEnabled = True
        Me.cmbQuantity1.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbQuantity1.Location = New System.Drawing.Point(814, 93)
        Me.cmbQuantity1.Name = "cmbQuantity1"
        Me.cmbQuantity1.Size = New System.Drawing.Size(94, 24)
        Me.cmbQuantity1.TabIndex = 134
        '
        'lblQuantity1
        '
        Me.lblQuantity1.AutoSize = True
        Me.lblQuantity1.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity1.ForeColor = System.Drawing.Color.White
        Me.lblQuantity1.Location = New System.Drawing.Point(736, 97)
        Me.lblQuantity1.Name = "lblQuantity1"
        Me.lblQuantity1.Size = New System.Drawing.Size(72, 20)
        Me.lblQuantity1.TabIndex = 133
        Me.lblQuantity1.Text = "Quantity:"
        '
        'txtTotal5
        '
        Me.txtTotal5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal5.Location = New System.Drawing.Point(932, 287)
        Me.txtTotal5.Name = "txtTotal5"
        Me.txtTotal5.ReadOnly = True
        Me.txtTotal5.Size = New System.Drawing.Size(115, 24)
        Me.txtTotal5.TabIndex = 147
        Me.txtTotal5.Visible = False
        '
        'txtTotal4
        '
        Me.txtTotal4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal4.Location = New System.Drawing.Point(932, 239)
        Me.txtTotal4.Name = "txtTotal4"
        Me.txtTotal4.ReadOnly = True
        Me.txtTotal4.Size = New System.Drawing.Size(115, 24)
        Me.txtTotal4.TabIndex = 146
        Me.txtTotal4.Visible = False
        '
        'txtTotal3
        '
        Me.txtTotal3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal3.Location = New System.Drawing.Point(932, 192)
        Me.txtTotal3.Name = "txtTotal3"
        Me.txtTotal3.ReadOnly = True
        Me.txtTotal3.Size = New System.Drawing.Size(115, 24)
        Me.txtTotal3.TabIndex = 145
        Me.txtTotal3.Visible = False
        '
        'txtTotal2
        '
        Me.txtTotal2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal2.Location = New System.Drawing.Point(932, 144)
        Me.txtTotal2.Name = "txtTotal2"
        Me.txtTotal2.ReadOnly = True
        Me.txtTotal2.Size = New System.Drawing.Size(115, 24)
        Me.txtTotal2.TabIndex = 144
        Me.txtTotal2.Visible = False
        '
        'txtTotal1
        '
        Me.txtTotal1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal1.Location = New System.Drawing.Point(932, 91)
        Me.txtTotal1.Name = "txtTotal1"
        Me.txtTotal1.ReadOnly = True
        Me.txtTotal1.Size = New System.Drawing.Size(115, 24)
        Me.txtTotal1.TabIndex = 143
        '
        'btnAdd1
        '
        Me.btnAdd1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd1.FlatAppearance.BorderSize = 2
        Me.btnAdd1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd1.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd1.Location = New System.Drawing.Point(1064, 89)
        Me.btnAdd1.Name = "btnAdd1"
        Me.btnAdd1.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd1.TabIndex = 148
        Me.btnAdd1.Text = "Add to Cart"
        Me.btnAdd1.UseVisualStyleBackColor = True
        '
        'btnAdd2
        '
        Me.btnAdd2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd2.FlatAppearance.BorderSize = 2
        Me.btnAdd2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd2.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd2.Location = New System.Drawing.Point(1064, 142)
        Me.btnAdd2.Name = "btnAdd2"
        Me.btnAdd2.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd2.TabIndex = 149
        Me.btnAdd2.Text = "Add to Cart"
        Me.btnAdd2.UseVisualStyleBackColor = True
        Me.btnAdd2.Visible = False
        '
        'btnAdd3
        '
        Me.btnAdd3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd3.FlatAppearance.BorderSize = 2
        Me.btnAdd3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd3.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd3.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd3.Location = New System.Drawing.Point(1064, 188)
        Me.btnAdd3.Name = "btnAdd3"
        Me.btnAdd3.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd3.TabIndex = 150
        Me.btnAdd3.Text = "Add to Cart"
        Me.btnAdd3.UseVisualStyleBackColor = True
        Me.btnAdd3.Visible = False
        '
        'btnAdd4
        '
        Me.btnAdd4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAdd4.FlatAppearance.BorderSize = 2
        Me.btnAdd4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnAdd4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd4.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd4.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnAdd4.Location = New System.Drawing.Point(1064, 239)
        Me.btnAdd4.Name = "btnAdd4"
        Me.btnAdd4.Size = New System.Drawing.Size(95, 30)
        Me.btnAdd4.TabIndex = 151
        Me.btnAdd4.Text = "Add to Cart"
        Me.btnAdd4.UseVisualStyleBackColor = True
        Me.btnAdd4.Visible = False
        '
        'btnOrder5
        '
        Me.btnOrder5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnOrder5.FlatAppearance.BorderSize = 2
        Me.btnOrder5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnOrder5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnOrder5.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder5.ForeColor = System.Drawing.Color.DarkRed
        Me.btnOrder5.Location = New System.Drawing.Point(1092, 364)
        Me.btnOrder5.Name = "btnOrder5"
        Me.btnOrder5.Size = New System.Drawing.Size(114, 30)
        Me.btnOrder5.TabIndex = 157
        Me.btnOrder5.Text = "Order Now"
        Me.btnOrder5.UseVisualStyleBackColor = True
        '
        'TblPricesTableAdapter
        '
        Me.TblPricesTableAdapter.ClearBeforeFill = True
        '
        'TblPricesTableAdapter1
        '
        Me.TblPricesTableAdapter1.ClearBeforeFill = True
        '
        'TblPricesTableAdapter2
        '
        Me.TblPricesTableAdapter2.ClearBeforeFill = True
        '
        'TblPricesTableAdapter3
        '
        Me.TblPricesTableAdapter3.ClearBeforeFill = True
        '
        'TblPricesTableAdapter4
        '
        Me.TblPricesTableAdapter4.ClearBeforeFill = True
        '
        'TblPricesTableAdapter5
        '
        Me.TblPricesTableAdapter5.ClearBeforeFill = True
        '
        'TblPricesTableAdapter6
        '
        Me.TblPricesTableAdapter6.ClearBeforeFill = True
        '
        'TblProductsTableAdapter
        '
        Me.TblProductsTableAdapter.ClearBeforeFill = True
        '
        'TblPricesTableAdapter7
        '
        Me.TblPricesTableAdapter7.ClearBeforeFill = True
        '
        'TblPricesTableAdapter8
        '
        Me.TblPricesTableAdapter8.ClearBeforeFill = True
        '
        'txtAllTotal
        '
        Me.txtAllTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAllTotal.Location = New System.Drawing.Point(932, 367)
        Me.txtAllTotal.Name = "txtAllTotal"
        Me.txtAllTotal.ReadOnly = True
        Me.txtAllTotal.Size = New System.Drawing.Size(115, 24)
        Me.txtAllTotal.TabIndex = 158
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(825, 371)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 20)
        Me.Label1.TabIndex = 159
        Me.Label1.Text = "Total:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.lblCustomerName1, Me.ToolStripStatusLabel1, Me.lblCustomerName})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 450)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1308, 31)
        Me.StatusStrip1.TabIndex = 160
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(133, 26)
        Me.ToolStripStatusLabel2.Text = "Customer ID:"
        '
        'lblCustomerName1
        '
        Me.lblCustomerName1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblCustomerName1.ForeColor = System.Drawing.Color.Gold
        Me.lblCustomerName1.Name = "lblCustomerName1"
        Me.lblCustomerName1.Size = New System.Drawing.Size(66, 26)
        Me.lblCustomerName1.Text = "Name"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(164, 26)
        Me.ToolStripStatusLabel1.Text = "Customer Name:"
        '
        'lblCustomerName
        '
        Me.lblCustomerName.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblCustomerName.ForeColor = System.Drawing.Color.Gold
        Me.lblCustomerName.Name = "lblCustomerName"
        Me.lblCustomerName.Size = New System.Drawing.Size(66, 26)
        Me.lblCustomerName.Text = "Name"
        '
        'frmOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1308, 481)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtAllTotal)
        Me.Controls.Add(Me.btnOrder5)
        Me.Controls.Add(Me.btnAdd4)
        Me.Controls.Add(Me.btnAdd3)
        Me.Controls.Add(Me.btnAdd2)
        Me.Controls.Add(Me.btnAdd1)
        Me.Controls.Add(Me.txtTotal5)
        Me.Controls.Add(Me.txtTotal4)
        Me.Controls.Add(Me.txtTotal3)
        Me.Controls.Add(Me.txtTotal2)
        Me.Controls.Add(Me.txtTotal1)
        Me.Controls.Add(Me.cmbQuantity5)
        Me.Controls.Add(Me.lblQuantity5)
        Me.Controls.Add(Me.cmbQuantity4)
        Me.Controls.Add(Me.lblQuantity4)
        Me.Controls.Add(Me.cmbQuantity3)
        Me.Controls.Add(Me.lblQuantity3)
        Me.Controls.Add(Me.cmbQuantity2)
        Me.Controls.Add(Me.lblQuantity2)
        Me.Controls.Add(Me.cmbQuantity1)
        Me.Controls.Add(Me.lblQuantity1)
        Me.Controls.Add(Me.txtPrice5)
        Me.Controls.Add(Me.txtPrice4)
        Me.Controls.Add(Me.txtPrice3)
        Me.Controls.Add(Me.txtPrice2)
        Me.Controls.Add(Me.txtPrice1)
        Me.Controls.Add(Me.lblPrice5)
        Me.Controls.Add(Me.lblPrice4)
        Me.Controls.Add(Me.lblPrice3)
        Me.Controls.Add(Me.lblPrice2)
        Me.Controls.Add(Me.lblPrice1)
        Me.Controls.Add(Me.cmbProduct5)
        Me.Controls.Add(Me.lblProduct5)
        Me.Controls.Add(Me.cmbProduct4)
        Me.Controls.Add(Me.lblProduct4)
        Me.Controls.Add(Me.cmbProduct3)
        Me.Controls.Add(Me.lblProduct3)
        Me.Controls.Add(Me.cmbProduct2)
        Me.Controls.Add(Me.lblProduct2)
        Me.Controls.Add(Me.cmbProduct1)
        Me.Controls.Add(Me.lblProduct1)
        Me.Controls.Add(Me.cmbCategory5)
        Me.Controls.Add(Me.cmbCategory4)
        Me.Controls.Add(Me.cmbCategory3)
        Me.Controls.Add(Me.cmbCategory2)
        Me.Controls.Add(Me.cmbCategory1)
        Me.Controls.Add(Me.lblCategory5)
        Me.Controls.Add(Me.lblCategory4)
        Me.Controls.Add(Me.lblCategory3)
        Me.Controls.Add(Me.lblCategory2)
        Me.Controls.Add(Me.lblCategory1)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label10)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Touch Salon System : Order"
        CType(Me.TblPricesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemCategory5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemProduct1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemProduct2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemProduct3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemProduct4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProductsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemProduct5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPricesBindingSource8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblCategory1 As System.Windows.Forms.Label
    Friend WithEvents lblCategory2 As System.Windows.Forms.Label
    Friend WithEvents lblCategory3 As System.Windows.Forms.Label
    Friend WithEvents lblCategory4 As System.Windows.Forms.Label
    Friend WithEvents lblCategory5 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbCategory2 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbCategory3 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbCategory4 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbCategory5 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbProduct1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblProduct1 As System.Windows.Forms.Label
    Friend WithEvents cmbProduct2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblProduct2 As System.Windows.Forms.Label
    Friend WithEvents cmbProduct3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblProduct3 As System.Windows.Forms.Label
    Friend WithEvents cmbProduct4 As System.Windows.Forms.ComboBox
    Friend WithEvents lblProduct4 As System.Windows.Forms.Label
    Friend WithEvents cmbProduct5 As System.Windows.Forms.ComboBox
    Friend WithEvents lblProduct5 As System.Windows.Forms.Label
    Friend WithEvents lblPrice5 As System.Windows.Forms.Label
    Friend WithEvents lblPrice4 As System.Windows.Forms.Label
    Friend WithEvents lblPrice3 As System.Windows.Forms.Label
    Friend WithEvents lblPrice2 As System.Windows.Forms.Label
    Friend WithEvents lblPrice1 As System.Windows.Forms.Label
    Friend WithEvents txtPrice1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPrice2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPrice3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPrice4 As System.Windows.Forms.TextBox
    Friend WithEvents txtPrice5 As System.Windows.Forms.TextBox
    Friend WithEvents cmbQuantity5 As System.Windows.Forms.ComboBox
    Friend WithEvents lblQuantity5 As System.Windows.Forms.Label
    Friend WithEvents cmbQuantity4 As System.Windows.Forms.ComboBox
    Friend WithEvents lblQuantity4 As System.Windows.Forms.Label
    Friend WithEvents cmbQuantity3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblQuantity3 As System.Windows.Forms.Label
    Friend WithEvents cmbQuantity2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblQuantity2 As System.Windows.Forms.Label
    Friend WithEvents cmbQuantity1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblQuantity1 As System.Windows.Forms.Label
    Friend WithEvents txtTotal5 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal4 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal3 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal1 As System.Windows.Forms.TextBox
    Friend WithEvents btnAdd1 As System.Windows.Forms.Button
    Friend WithEvents btnAdd2 As System.Windows.Forms.Button
    Friend WithEvents btnAdd3 As System.Windows.Forms.Button
    Friend WithEvents btnAdd4 As System.Windows.Forms.Button
    Friend WithEvents btnOrder5 As System.Windows.Forms.Button
    Friend WithEvents TouchSalonSystemCategory1 As TouchSuiteSalon.TouchSalonSystemCategory1
    Friend WithEvents TblPricesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter As TouchSuiteSalon.TouchSalonSystemCategory1TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemProduct1 As TouchSuiteSalon.TouchSalonSystemProduct1
    Friend WithEvents TblPricesBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter1 As TouchSuiteSalon.TouchSalonSystemProduct1TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemCategory2 As TouchSuiteSalon.TouchSalonSystemCategory2
    Friend WithEvents TblPricesBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter2 As TouchSuiteSalon.TouchSalonSystemCategory2TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemProduct2 As TouchSuiteSalon.TouchSalonSystemProduct2
    Friend WithEvents TblPricesBindingSource3 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter3 As TouchSuiteSalon.TouchSalonSystemProduct2TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemCategory3 As TouchSuiteSalon.TouchSalonSystemCategory3
    Friend WithEvents TblPricesBindingSource4 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter4 As TouchSuiteSalon.TouchSalonSystemCategory3TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemProduct3 As TouchSuiteSalon.TouchSalonSystemProduct3
    Friend WithEvents TblPricesBindingSource5 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter5 As TouchSuiteSalon.TouchSalonSystemProduct3TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemCategory4 As TouchSuiteSalon.TouchSalonSystemCategory4
    Friend WithEvents TblPricesBindingSource6 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter6 As TouchSuiteSalon.TouchSalonSystemCategory4TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemProduct4 As TouchSuiteSalon.TouchSalonSystemProduct4
    Friend WithEvents TblProductsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProductsTableAdapter As TouchSuiteSalon.TouchSalonSystemProduct4TableAdapters.tblProductsTableAdapter
    Friend WithEvents TouchSalonSystemCategory5 As TouchSuiteSalon.TouchSalonSystemCategory5
    Friend WithEvents TblPricesBindingSource7 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter7 As TouchSuiteSalon.TouchSalonSystemCategory5TableAdapters.tblPricesTableAdapter
    Friend WithEvents TouchSalonSystemProduct5 As TouchSuiteSalon.TouchSalonSystemProduct5
    Friend WithEvents TblPricesBindingSource8 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPricesTableAdapter8 As TouchSuiteSalon.TouchSalonSystemProduct5TableAdapters.tblPricesTableAdapter
    Friend WithEvents txtAllTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCustomerName As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCustomerName1 As System.Windows.Forms.ToolStripStatusLabel
End Class
