﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmGuestMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmGuestMenu))
        Me.btnAboutUS = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.btnProducts = New System.Windows.Forms.Button()
        Me.btnStaff = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnClients = New System.Windows.Forms.Button()
        Me.CloudClock1 = New CloudToolkitN6.CloudClock()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnAboutUS
        '
        Me.btnAboutUS.BackgroundImage = CType(resources.GetObject("btnAboutUS.BackgroundImage"), System.Drawing.Image)
        Me.btnAboutUS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAboutUS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAboutUS.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnAboutUS.Location = New System.Drawing.Point(907, 502)
        Me.btnAboutUS.Name = "btnAboutUS"
        Me.btnAboutUS.Size = New System.Drawing.Size(460, 250)
        Me.btnAboutUS.TabIndex = 17
        Me.btnAboutUS.Text = "About Us"
        Me.btnAboutUS.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), System.Drawing.Image)
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button8.Location = New System.Drawing.Point(907, 252)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(460, 250)
        Me.Button8.TabIndex = 16
        Me.Button8.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.BackgroundImage = CType(resources.GetObject("btnReports.BackgroundImage"), System.Drawing.Image)
        Me.btnReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnReports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReports.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnReports.Location = New System.Drawing.Point(907, 2)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(460, 250)
        Me.btnReports.TabIndex = 15
        Me.btnReports.Text = "Comments"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), System.Drawing.Image)
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button6.Location = New System.Drawing.Point(451, 502)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(460, 250)
        Me.Button6.TabIndex = 14
        Me.Button6.UseVisualStyleBackColor = True
        '
        'btnProducts
        '
        Me.btnProducts.BackgroundImage = CType(resources.GetObject("btnProducts.BackgroundImage"), System.Drawing.Image)
        Me.btnProducts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnProducts.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProducts.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnProducts.Location = New System.Drawing.Point(451, 252)
        Me.btnProducts.Name = "btnProducts"
        Me.btnProducts.Size = New System.Drawing.Size(460, 250)
        Me.btnProducts.TabIndex = 13
        Me.btnProducts.Text = "Products"
        Me.btnProducts.UseVisualStyleBackColor = True
        '
        'btnStaff
        '
        Me.btnStaff.BackgroundImage = CType(resources.GetObject("btnStaff.BackgroundImage"), System.Drawing.Image)
        Me.btnStaff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnStaff.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStaff.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnStaff.Location = New System.Drawing.Point(0, 502)
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(460, 250)
        Me.btnStaff.TabIndex = 11
        Me.btnStaff.Text = "Staffs"
        Me.btnStaff.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button2.Location = New System.Drawing.Point(-5, 252)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(460, 250)
        Me.Button2.TabIndex = 10
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnClients
        '
        Me.btnClients.BackgroundImage = CType(resources.GetObject("btnClients.BackgroundImage"), System.Drawing.Image)
        Me.btnClients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnClients.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClients.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClients.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon
        Me.btnClients.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClients.Location = New System.Drawing.Point(0, 27)
        Me.btnClients.Name = "btnClients"
        Me.btnClients.Size = New System.Drawing.Size(460, 225)
        Me.btnClients.TabIndex = 9
        Me.btnClients.Text = "Services"
        Me.btnClients.UseVisualStyleBackColor = False
        '
        'CloudClock1
        '
        Me.CloudClock1.BackColor = System.Drawing.Color.Transparent
        Me.CloudClock1.BackColorLower = System.Drawing.Color.Transparent
        Me.CloudClock1.BackColorUpper = System.Drawing.Color.DarkGreen
        Me.CloudClock1.ControlOpacity = 255
        Me.CloudClock1.FirstShadeColor = System.Drawing.Color.White
        Me.CloudClock1.FontColor = System.Drawing.Color.White
        Me.CloudClock1.FontSize = 13
        Me.CloudClock1.Location = New System.Drawing.Point(620, 59)
        Me.CloudClock1.Name = "CloudClock1"
        Me.CloudClock1.NeedleColor_Center = System.Drawing.Color.White
        Me.CloudClock1.NeedleColor_Minute = System.Drawing.Color.LightCyan
        Me.CloudClock1.NeedleColorCenter_Hour = System.Drawing.Color.LightCyan
        Me.CloudClock1.NeedleColorCenter_Second = System.Drawing.Color.DarkSlateGray
        Me.CloudClock1.NeedleLength_Hour = 25.0!
        Me.CloudClock1.NeedleLength_Minute = 42.85714!
        Me.CloudClock1.NeedleLength_Second = 33.33333!
        Me.CloudClock1.NeedleWidth_Hour = 3.0!
        Me.CloudClock1.NeedleWidth_Minute = 3.0!
        Me.CloudClock1.NeedleWidth_Second = 3.0!
        Me.CloudClock1.NumberOfSlashes = 12
        Me.CloudClock1.NumberPadding = 20
        Me.CloudClock1.ShadeTransparency = 100
        Me.CloudClock1.Size = New System.Drawing.Size(150, 150)
        Me.CloudClock1.SlashColor = System.Drawing.Color.White
        Me.CloudClock1.SlashLength = 6
        Me.CloudClock1.SlashWidth = 1.0!
        Me.CloudClock1.TabIndex = 28
        Me.CloudClock1.Value_Hour = 190.5!
        Me.CloudClock1.Value_Minute = 36.0!
        Me.CloudClock1.Value_Second = 60.0!
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 29
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'FrmGuestMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1370, 750)
        Me.Controls.Add(Me.CloudClock1)
        Me.Controls.Add(Me.btnAboutUS)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.btnProducts)
        Me.Controls.Add(Me.btnStaff)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnClients)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.Transparent
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmGuestMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Guest Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAboutUS As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents btnReports As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents btnProducts As System.Windows.Forms.Button
    Friend WithEvents btnStaff As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnClients As System.Windows.Forms.Button
    Friend WithEvents CloudClock1 As CloudToolkitN6.CloudClock
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
