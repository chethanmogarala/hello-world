﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Public Class frmClientSearch




    Private Sub TabPage4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TabPage3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblContact_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblEmailAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblGender_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblBirthday_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblAge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtCustomerName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtAddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtContact_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtEmailAdd_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub cmbGender_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtAge_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub

    Private Sub TabPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub lblTitle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblTitle.Click

    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

   

    Private Sub BtnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'conn = GetConnect()
        'Try
        '    conn.Open()
        '    cmd = New SqlCommand("Select * from tblCustomerInfo where MembersID = '" & txtUMemeberID.Text & "'", conn)
        '    Dim read As SqlDataReader = cmd.ExecuteReader
        '    If read.HasRows = True Then
        '        While read.Read

        '            txtUFirstName.Text = read("FirstName".ToString)
        '            txtULastName.Text = read("LastName".ToString)
        '            txtUInitial.Text = read("Initial".ToString)
        '            cmbUGender.Text = read("Gender".ToString)
        '            DateTimePicker2.Text = read("Birthday".ToString)
        '            txtUAge.Text = read("Age".ToString)
        '            txtUAddress.Text = read("Address".ToString)
        '            txtUContactNo.Text = read("ContactNo".ToString)
        '            txtUEmailAdd.Text = read("EmailAddress".ToString)
        '            DateTimePicker3.Text = read("DateT".ToString)
        '        End While

        '    Else
        '        MsgBox("No Rows Selected!")


        '    End If
        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try
    End Sub

    Private Sub frmClient_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtContact.MaxLength = 13 '// set max. allowed characters.
        txtAge.MaxLength = 2 '// set max. allowed characters.
        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        lblTime.Text = TimeOfDay
        lblTime.Text = Format(Now, "HH:mm:ss")


        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblCustomerInfo", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblCustomerInfo")
            DataGridView1.DataSource = ds.Tables("tblCustomerInfo")
            '---------------------------------------------------------



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

  
    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        txtCustomerID.Text = DataGridView1.Item(0, i).Value
        txtFirstName.Text = DataGridView1.Item(1, i).Value
        cmbGender.Text = DataGridView1.Item(2, i).Value
        DateTimePicker1.Text = DataGridView1.Item(3, i).Value
        txtAge.Text = DataGridView1.Item(4, i).Value
        txtAddress.Text = DataGridView1.Item(5, i).Value
        txtSubdivision.Text = DataGridView1.Item(6, i).Value
        txtCity.Text = DataGridView1.Item(7, i).Value
        txtContact.Text = DataGridView1.Item(8, i).Value
        txtEmailAdd.Text = DataGridView1.Item(9, i).Value
        DateTimePicker2.Text = DataGridView1.Item(10, i).Value

        conn = GetConnect()

    End Sub

    Public Sub clear()

        txtFirstName.Text = ""
        cmbGender.Text = ""
        DateTimePicker1.Text = ""
        txtAge.Text = ""
        txtAddress.Text = ""
        txtSubdivision.Text = ""
        txtCity.Text = ""
        txtContact.Text = ""
        txtEmailAdd.Text = ""
    End Sub


    Private Sub txtFirstName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFirstName.KeyPress
        If (Microsoft.VisualBasic.Asc(e.KeyChar) < 65) _
            Or (Microsoft.VisualBasic.Asc(e.KeyChar) > 90) _
            And (Microsoft.VisualBasic.Asc(e.KeyChar) < 97) _
            Or (Microsoft.VisualBasic.Asc(e.KeyChar) > 122) Then
            'Allowed space
            If (Microsoft.VisualBasic.Asc(e.KeyChar) <> 32) Then
                e.Handled = True
            End If
        End If
        ' Allowed backspace
        If (Microsoft.VisualBasic.Asc(e.KeyChar) = 8) Then
            e.Handled = False
        End If
    End Sub





    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Search Student Info
        conn = GetConnect()
        Try
            conn.Open()
            cmd = New MySqlCommand("Select * from tblCustomerInfo  where MembersID = '" & txtCustomerID.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    txtCustomerID.Text = read("MembersID".ToString)
                    txtFirstName.Text = read("FullName".ToString)
                    cmbGender.Text = read("Gender".ToString)
                    DateTimePicker1.Text = read("Birthday".ToString)
                    txtAge.Text = read("Age".ToString)
                    txtAddress.Text = read("Street".ToString)
                    txtSubdivision.Text = read("Subdivision".ToString)
                    txtCity.Text = read("City".ToString)
                    txtContact.Text = read("ContactNo".ToString)
                    txtEmailAdd.Text = read("EmailAddress".ToString)
                    'DateTimePicker2.Text = read("Expiration".ToString)


                End While

            ElseIf txtCustomerID.Text = "" Then

                MsgBox("Insert Customer ID!")
                txtCustomerID.ReadOnly = False

                txtCustomerID.Focus()
            Else
                MsgBox("No Rows Selected!")

                txtCustomerID.Focus()
            End If

         

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub phonenumbertxtbox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContact.KeyPress
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "(", ")", "-", vbBack '// your pre-selected Characters and Backspace.
                e.Handled = False '// allow.
            Case Else
                e.Handled = True '// block.

        End Select
    End Sub
    Private Sub phonenumbertxtbox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAge.KeyPress
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "(", ")", vbBack '// your pre-selected Characters and Backspace.
                e.Handled = False '// allow.
            Case Else
                e.Handled = True '// block.

        End Select
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtFirstName.Text = "" Then
            MsgBox("Please enter your Name")
            txtFirstName.Focus()

        ElseIf txtAge.Text = "" Then
            MsgBox("Please enter your Age")
            txtAge.Focus()

        ElseIf txtAddress.Text = "" Then
            MsgBox("Please enter your Address")
            txtAddress.Focus()

        ElseIf txtCity.Text = "" Then
            MsgBox("Please enter your City")
            txtCity.Focus()

        ElseIf txtContact.Text = "" Then
            MsgBox("Please enter your Contact Number")
            txtContact.Focus()

        Else

            conn = GetConnect()
            Try
                conn.Open()
                str = "Insert into tblCustomerInfo values ('','" & txtFirstName.Text & "', '" & cmbGender.Text & "', '" & DateTimePicker1.Text & "', '" & txtAge.Text & "', '" & txtAddress.Text & "', '" & txtSubdivision.Text & "', '" & txtCity.Text & "', '" & txtContact.Text & "', '" & txtEmailAdd.Text & "','" & DateTimePicker2.Text & "')"
                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Saved Successfully!")
                clear()
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try

            Try
                ' ORIG ------------------------------------------------------------
                conn.Open()
                '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
                cmd = New MySqlCommand("select * from tblCustomerInfo", conn)
                da = New MySqlDataAdapter(cmd)
                ds.Clear()
                da.Fill(ds, "tblCustomerInfo")
                DataGridView1.DataSource = ds.Tables("tblCustomerInfo")
                '---------------------------------------------------------
                conn.Close()


            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            DataGridView1.Refresh()
        End If
    End Sub

    
    Private Sub btnCancel_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        clear()
    End Sub

  
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Update tblCustomerInfo set FullName = '" & txtFirstName.Text & "', Gender =  '" & cmbGender.Text & "', Birthday = '" & DateTimePicker1.Text & "', Age = '" & txtAge.Text & "', Street = '" & txtAddress.Text & "', Subdivision = '" & txtSubdivision.Text & "', City = '" & txtCity.Text & "', ContactNo = '" & txtContact.Text & "', EmailAddress = '" & txtEmailAdd.Text & "' , Membership = '" & DateTimePicker2.Text & "'  where MembersID = '" & txtCustomerID.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            'conn.Close()
            MsgBox("Record Updated Successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblCustomerInfo", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblCustomerInfo")
            DataGridView1.DataSource = ds.Tables("tblCustomerInfo")
            '---------------------------------------------------------
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        DataGridView1.Refresh()
    End Sub

  
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        'Delete
        Dim i As Integer
        i = MsgBox("Are you sure you want to delete the record?", vbYesNo, "Touch Suite Salon")
        If i = vbYes Then
            conn = GetConnect()
            Try
                conn.Open()
                str = "Delete from tblCustomerInfo where MembersID = '" & txtCustomerID.Text & "'"
                cmd = New MySqlCommand(str, conn)


                cmd.ExecuteNonQuery()
                conn.Close()

                txtCustomerID.Text = ""
                txtFirstName.Text = ""
                cmbGender.Text = ""
                DateTimePicker1.Text = ""
                txtAge.Text = ""
                txtAddress.Text = ""
                txtSubdivision.Text = ""
                txtCity.Text = ""
                txtContact.Text = ""
                txtEmailAdd.Text = ""
                DateTimePicker2.Text = ""

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            conn.Close()
            Try
                ' ORIG ------------------------------------------------------------
                conn.Open()
                '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
                cmd = New MySqlCommand("select * from tblCustomerInfo", conn)
                da = New MySqlDataAdapter(cmd)
                ds.Clear()
                da.Fill(ds, "tblCustomerInfo")
                DataGridView1.DataSource = ds.Tables("tblCustomerInfo")
                '---------------------------------------------------------
                conn.Close()


            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            DataGridView1.Refresh()
        End If
    End Sub

   
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub txtAge_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAge.TextChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged() Handles DateTimePicker1.ValueChanged
        Dim Birth As Date = DateTimePicker1.Value
        Dim year, month, day As Integer
        While year <= (Now.Year - Birth.Year)
            While month <= (Now.Month - Birth.Month)
                While day <= (Now.Day - Birth.Day)
                    day += 1
                End While
                month += 1
            End While
            year += 1
        End While
        year -= 1 : month -= 1 : day -= 1
        txtAge.Text = year
        ' MsgBox(year & " year " & month & " month " & day & " day")
    End Sub


    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSubdivision.TextChanged

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
