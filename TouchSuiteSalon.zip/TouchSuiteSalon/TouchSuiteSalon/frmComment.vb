﻿Imports MySql.Data.MySqlClient
Public Class frmComment

    Private Sub frmComment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        lblTime.Text = TimeOfDay
        lblTime.Text = Format(Now, "HH:mm:ss")

    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Insert into tblComments values ('" & RichTextBox1.Text & "', '" & lblDate.Text & "')"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")
            RichTextBox1.Text = ""

            conn.Close()
            Me.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class