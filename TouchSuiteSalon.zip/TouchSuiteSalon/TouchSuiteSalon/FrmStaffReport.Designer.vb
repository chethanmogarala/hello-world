﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmStaffReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmStaffReport))
        Me.tblEmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TouchSalonSystemStaff = New TouchSuiteSalon.TouchSalonSystemStaff()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.tblEmployeeTableAdapter = New TouchSuiteSalon.TouchSalonSystemStaffTableAdapters.tblEmployeeTableAdapter()
        Me.BtnClose = New System.Windows.Forms.Button()
        CType(Me.tblEmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TouchSalonSystemStaff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tblEmployeeBindingSource
        '
        Me.tblEmployeeBindingSource.DataMember = "tblEmployee"
        Me.tblEmployeeBindingSource.DataSource = Me.TouchSalonSystemStaff
        '
        'TouchSalonSystemStaff
        '
        Me.TouchSalonSystemStaff.DataSetName = "TouchSalonSystemStaff"
        Me.TouchSalonSystemStaff.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReportViewer1
        '
        ReportDataSource1.Name = "DSStaff"
        ReportDataSource1.Value = Me.tblEmployeeBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "TouchSuiteSalon.Report4.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(24, 48)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(733, 463)
        Me.ReportViewer1.TabIndex = 0
        '
        'tblEmployeeTableAdapter
        '
        Me.tblEmployeeTableAdapter.ClearBeforeFill = True
        '
        'BtnClose
        '
        Me.BtnClose.BackgroundImage = CType(resources.GetObject("BtnClose.BackgroundImage"), System.Drawing.Image)
        Me.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnClose.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.ForeColor = System.Drawing.Color.Transparent
        Me.BtnClose.Location = New System.Drawing.Point(651, 528)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(106, 33)
        Me.BtnClose.TabIndex = 3
        Me.BtnClose.Text = "&Close"
        Me.BtnClose.UseVisualStyleBackColor = True
        '
        'FrmStaffReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(781, 573)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmStaffReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Touch Salon System : Staff's Report"
        CType(Me.tblEmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TouchSalonSystemStaff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents tblEmployeeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TouchSalonSystemStaff As TouchSuiteSalon.TouchSalonSystemStaff
    Friend WithEvents tblEmployeeTableAdapter As TouchSuiteSalon.TouchSalonSystemStaffTableAdapters.tblEmployeeTableAdapter
    Friend WithEvents BtnClose As System.Windows.Forms.Button
End Class
