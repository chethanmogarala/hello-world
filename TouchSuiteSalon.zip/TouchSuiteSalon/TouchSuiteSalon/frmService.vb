﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmService

    Private Sub frmService_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      
       
        lblDate.Text = Format(Now, "MMMM dd, yyyy")

        conn = GetConnect()
        Try
            conn.Open()
            cmd = New MySqlCommand("Select MembersID, FullName from tblCustomerInfo where MembersID = '" & frmServiceLogin.txtMemberID.Text & "'", conn)

            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    lblCustomerName1.Text = read("MembersID".ToString)
                    lblCustomerName.Text = read("FullName".ToString)
                    ' lblUserName.Text = read("UserName".ToString)
                End While
            Else
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory_11.tblServices' table. You can move, or remove it, as needed.
        'Me.TblServicesTableAdapter.Fill(Me.TouchSalonSystemCategory_11.tblServices)
    End Sub

    Private Sub btnOrder5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder5.Click
        Dim i As Integer
        i = MsgBox("Is your Orders correct?", vbYesNo, "Touch Suite Salon")
        If i = vbYes Then
            conn = GetConnect()
            Try
                conn.Open()
                str = "Insert into tblServiceBilling values ('" & lblCustomerName1.Text & "', '" & lblCustomerName.Text & "', '" & cmbCategory1.Text & "', '" & cmbCategory2.Text & "', '" & cmbCategory3.Text & "', '" & cmbCategory4.Text & "', '" & cmbService1.Text & "', '" & cmbService2.Text & "','" & cmbService3.Text & "','" & cmbService4.Text & "', '" & txtPrice1.Text & "', '" & txtPrice2.Text & "','" & txtPrice3.Text & "','" & txtPrice4.Text & "','" & txtAllTotal.Text & "','" & lblDate.Text & "')"
                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Your service is now aligned, Please go to receptionist.")

                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try


            Me.Close()

        End If
    End Sub

    Private Sub btnAdd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd1.Click
        lblCategory2.Visible = True
        cmbCategory2.Visible = True
        lblService2.Visible = True
        cmbService2.Visible = True
        lblPrice2.Visible = True
        txtPrice2.Visible = True
        btnAdd2.Visible = True
    End Sub

    Private Sub btnAdd2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        lblCategory3.Visible = True
        cmbCategory3.Visible = True
        lblService3.Visible = True
        cmbService3.Visible = True
        lblPrice3.Visible = True
        txtPrice3.Visible = True
        btnAdd3.Visible = True
    End Sub

    Private Sub btnAdd3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd3.Click
        lblCategory4.Visible = True
        cmbCategory4.Visible = True
        lblService4.Visible = True
        cmbService4.Visible = True
        lblPrice4.Visible = True
        txtPrice4.Visible = True

    End Sub
    Private Sub cmbCategory1_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory1.DropDown
        Me.TblServicesTableAdapter4.Fill(Me.TouchSalonSystemService1.tblServices, cmbCategory1.Text)
    End Sub
    Private Sub cmbCategory1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory1.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemService1.tblServices' table. You can move, or remove it, as needed.
       Me.TblServicesTableAdapter4.Fill(Me.TouchSalonSystemService1.tblServices, cmbCategory1.Text)
    End Sub
    Private Sub cmbCategory2_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory2.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory_2.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter1.Fill(Me.TouchSalonSystemCategory_2.tblServices)
    End Sub
    Private Sub cmbCategory2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory2.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemService2.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter5.Fill(Me.TouchSalonSystemService2.tblServices, cmbCategory2.Text)

    End Sub
    Private Sub cmbCategory3_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory3.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory_3.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter2.Fill(Me.TouchSalonSystemCategory_3.tblServices)
    End Sub
    Private Sub cmbCategory3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory3.SelectedIndexChanged
       
        'TODO: This line of code loads data into the 'TouchSalonSystemService3.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter6.Fill(Me.TouchSalonSystemService3.tblServices, cmbCategory3.Text)
    End Sub
    Private Sub cmbCategory4_DropDown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory4.DropDown
        'TODO: This line of code loads data into the 'TouchSalonSystemCategory_4.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter3.Fill(Me.TouchSalonSystemCategory_4.tblServices)
    End Sub
    Private Sub cmbCategory4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory4.SelectedIndexChanged
        'TODO: This line of code loads data into the 'TouchSalonSystemService4.tblServices' table. You can move, or remove it, as needed.
        Me.TblServicesTableAdapter7.Fill(Me.TouchSalonSystemService4.tblServices, cmbCategory4.Text)
    End Sub

    Private Sub cmbService1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbService1.SelectedIndexChanged
        'Refresh()
        'Me.TblServicesTableAdapter4.Fill(Me.TouchSalonSystemService1.tblServices, cmbCategory1.Text)
        Dim price As Integer
        'Prices
        txtPrice1.Text = "0.00"
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Price from tblServices  where Services = '" & cmbService1.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Price".ToString)
                    txtPrice1.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()

            Dim total As Double
            total = CDec(txtPrice1.Text)
            txtAllTotal.Text = Format(total, "0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

       

    End Sub

    Private Sub cmbService2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbService2.SelectedIndexChanged
        'Refresh()
        'Me.TblServicesTableAdapter5.Fill(Me.TouchSalonSystemService2.tblServices, cmbCategory2.Text)
        Dim price As Integer
        'Prices

        txtPrice2.Text = "0.00"
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Price from tblServices  where Services = '" & cmbService2.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Price".ToString)
                    txtPrice2.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()
            Dim total As Double
            total = CDec(txtPrice1.Text) + CDec(txtPrice2.Text)
            txtAllTotal.Text = Format(total, "0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cmbService3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbService3.SelectedIndexChanged
       
        Dim price As Integer
        'Prices
        txtPrice3.Text = "0.00"
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Price from tblServices  where Services = '" & cmbService3.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Price".ToString)
                    txtPrice3.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()
            Dim total As Double
            total = CDec(txtPrice1.Text) + CDec(txtPrice2.Text) + CDec(txtPrice3.Text)
            txtAllTotal.Text = Format(total, "0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    

    Private Sub cmbService4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbService4.SelectedIndexChanged
     
        Dim price As Integer
        'Prices
        txtPrice4.Text = "0.00"
        conn = GetConnect()
        Try

            conn.Open()
            cmd = New MySqlCommand("Select Price from tblServices  where Services = '" & cmbService4.Text & "'", conn)
            Dim read As MySqlDataReader = cmd.ExecuteReader
            If read.HasRows = True Then
                While read.Read
                    price = read("Price".ToString)
                    txtPrice4.Text = Format(price, "0.00")
                End While
            End If
            conn.Close()
            Dim total As Double
            total = CDec(txtPrice1.Text) + CDec(txtPrice2.Text) + CDec(txtPrice3.Text) + CDec(txtPrice4.Text)
            txtAllTotal.Text = Format(total, "0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtAllTotal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAllTotal.TextChanged

    End Sub
End Class