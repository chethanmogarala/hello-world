﻿Public Class frmMembersReport

    Private Sub frmMembersReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TouchSalonSystemMembers.tblCustomerInfo' table. You can move, or remove it, as needed.
        ' Me.tblCustomerInfoTableAdapter.Fill(Me.TouchSalonSystemMembers.tblCustomerInfo)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class