﻿Imports System.IO

Imports System.Data

Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Data.SqlTypes
Imports MySql.Data.MySqlClient




Public Class frmProductsAdmin

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
      

        With OpenFileDialog1
            .InitialDirectory = "C:\"
            .Filter = "JPEG Files|*.jpg" & "|Bitmap Files|*.bmp" & "|Gif Files|*.gif" & "|All Files|*.*"
            .FilterIndex = 2
        End With

        ' When the user clicks the Open button (DialogResult.OK is the only option;
        ' there is not DialogResult.Open), display the image centered in the 
        ' PictureBox and display the full path of the image.
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            With pctImage

                .Image = Image.FromFile(OpenFileDialog1.FileName)
                '       .SizeMode = PictureBoxSizeMode.CenterImage
                .BorderStyle = BorderStyle.Fixed3D
            End With
            '        txtProduct1.Text = OpenFileDialog1.FileName
        End If
    End Sub


   
    Private Sub OpenFileDialog2_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog2.FileOk

        img = Image.FromFile(OpenFileDialog2.FileName)
        PictureBox1.Image = img
        OpenFileDialog2.Filter = "JPEG Files|*.jpg" & "|Bitmap Files|*.bmp" & "|Gif Files|*.gif" & "|All Files|*.*"
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.Image.Save(Application.StartupPath + "\temp.dat", Imaging.ImageFormat.Jpeg)
        str = OpenFileDialog1.FileName
        idno = 1

    End Sub
    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

        img = Image.FromFile(OpenFileDialog1.FileName)
        pctImage.Image = img
        OpenFileDialog1.Filter = "JPEG Files|*.jpg" & "|Bitmap Files|*.bmp" & "|Gif Files|*.gif" & "|All Files|*.*"
        pctImage.SizeMode = PictureBoxSizeMode.StretchImage
        pctImage.Image.Save(Application.StartupPath + "\temp.dat", Imaging.ImageFormat.Jpeg)
        str = OpenFileDialog1.FileName
        idno = 1

    End Sub


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        conn = GetConnect()
        'Dim arrFilename() As String = Split(txtProduct1.Text, "\")

        ' Array.Reverse(arrFilename)
        Dim ms As New MemoryStream()
        pctImage.Image.Save(ms, pctImage.Image.RawFormat)
        Dim arrImage() As Byte = ms.GetBuffer

        ms.Close()
        Try
            conn.Open()
            str = "INSERT INTO tblProducts (Image) VALUES (@Image)"
            'str = "Insert into tblProduct2 (Image1)" & "VALUES (@Image1)"
            cmd = New MySqlCommand(str, conn)
            With cmd
                ' Add parameters required by SQL statement. PictureID is an 
                ' identity field (in Microsoft Access, an AutoNumber field), 
                ' so you only need to pass values for the two remaining fields.
                
                .Parameters.Add(New MySqlParameter("@Image", _
                    SqlDbType.Image)).Value = arrImage
            End With
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

      


    End Sub

    Private Sub frmProductsAdmin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      
    End Sub

    Private Sub btnProducts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProducts.Click
        AddProducts.Show()
        Me.Close()

    End Sub

    
    Private Sub btnServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnServices.Click
        frmAddServices.Show()

    End Sub

    Private Sub btnProduct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProduct.Click
        GroupBox1.Visible = True
        btnService.Visible = False

    End Sub

    Private Sub btnService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnService.Click
        GroupBox2.Visible = True
        btnProduct.Visible = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        With OpenFileDialog2
            .InitialDirectory = "C:\"
            .Filter = "JPEG Files|*.jpg" & "|Bitmap Files|*.bmp" & "|Gif Files|*.gif" & "|All Files|*.*"
            .FilterIndex = 2
        End With

        ' When the user clicks the Open button (DialogResult.OK is the only option;
        ' there is not DialogResult.Open), display the image centered in the 
        ' PictureBox and display the full path of the image.
        If OpenFileDialog2.ShowDialog() = DialogResult.OK Then
            With PictureBox1

                .Image = Image.FromFile(OpenFileDialog2.FileName)
                '       .SizeMode = PictureBoxSizeMode.CenterImage
                .BorderStyle = BorderStyle.Fixed3D
            End With
            '        txtProduct1.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        conn = GetConnect()
        'Dim arrFilename() As String = Split(txtProduct1.Text, "\")

        ' Array.Reverse(arrFilename)
        Dim ms As New MemoryStream()
        PictureBox1.Image.Save(ms, PictureBox1.Image.RawFormat)
        Dim arrImage() As Byte = ms.GetBuffer

        ms.Close()
        Try
            conn.Open()
            str = "INSERT INTO tblServicesImage (Image) VALUES (@Image)"
            'str = "Insert into tblProduct2 (Image1)" & "VALUES (@Image1)"
            cmd = New MySqlCommand(str, conn)
            With cmd
                ' Add parameters required by SQL statement. PictureID is an 
                ' identity field (in Microsoft Access, an AutoNumber field), 
                ' so you only need to pass values for the two remaining fields.

                .Parameters.Add(New MySqlParameter("@Image", _
                    SqlDbType.Image)).Value = arrImage
            End With
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
End Class