﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.IO
Imports System.Drawing
Imports MySql.Data.MySqlClient
Public Class frmProducts

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        FrmGuestMenu.Show()

    End Sub

    Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2001", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox1.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox1.Show()


            lblProduct1.Text = drdr("Product".ToString)
            lblPrice1.Text = drdr("Price".ToString)

                
            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2002", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox2.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox2.Show()


            lblProduct2.Text = drdr("Product".ToString)
            lblPrice2.Text = drdr("Price".ToString)


            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2003", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox3.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox3.Show()


            lblProduct3.Text = drdr("Product".ToString)
            lblPrice3.Text = drdr("Price".ToString)


            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2004", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox4.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox4.Show()


            lblProduct4.Text = drdr("Product".ToString)
            lblPrice4.Text = drdr("Price".ToString)


            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2005", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox5.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox5.Show()


            lblProduct5.Text = drdr("Product".ToString)
            lblPrice5.Text = drdr("Price".ToString)


            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            '  cmd = New SqlCommand("select MembersID, LastName,FirstName, Expiration from tblCustomerInfo", conn)
            cmd = New MySqlCommand("select * from tblProducts where ID = 2006", conn)
            Dim drdr As MySqlDataReader
            drdr = cmd.ExecuteReader
            drdr.Read()
            Dim bt() As Byte
            Dim ms As MemoryStream
            bt = drdr.Item("Image")
            ms = New MemoryStream(bt)
            PictureBox6.Image = Image.FromStream(ms)
            'pctImage.Image = DataGridView1.Item(18, i).Value
            PictureBox6.Show()


            lblProduct6.Text = drdr("Product".ToString)
            lblPrice6.Text = drdr("Price".ToString)


            conn.Close()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''Delete
        'Dim i As Integer
        'i = MsgBox("Are you sure you want to reset your order?", vbYesNo, "Touch Suite Salon")
        'If i = vbYes Then


        '    ComboBox1.Text = ""
        '    ComboBox2.Text = ""
        '    ComboBox3.Text = ""
        '    ComboBox4.Text = ""
        '    ComboBox5.Text = ""
        '    ComboBox6.Text = ""

        'Else


        'End If
    End Sub


      
    'Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
    '    FrmMemberID.Show()
    '    Me.Close()




    '    'btnProceed.Visible = True
    '    'btnClear.Visible = True
    '    'ComboBox1.Visible = True
    '    'ComboBox2.Visible = True
    '    'ComboBox3.Visible = True
    '    'ComboBox4.Visible = True
    '    'ComboBox5.Visible = True
    '    'ComboBox6.Visible = True

    'End Sub

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click


        FrmMemberID.Show()
    End Sub
End Class