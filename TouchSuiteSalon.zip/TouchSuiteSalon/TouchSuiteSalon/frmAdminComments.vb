﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmAdminComments

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Me.Close()
        
    End Sub

    Private Sub frmAdminComments_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        conn = GetConnect()
        Try
            ' ORIG ------------------------------------------------------------
            conn.Open()
            cmd = New MySqlCommand("select * from tblComments", conn)
            da = New MySqlDataAdapter(cmd)
            ds.Clear()
            da.Fill(ds, "tblComments")
            DataGridView1.DataSource = ds.Tables("tblComments")
            '---------------------------------------------------------



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseUp
        'Putting infos from dbase to textboxes
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        lblID.Text = DataGridView1.Item(0, i).Value
        RichTextBox1.Text = DataGridView1.Item(1, i).Value
        lblDate.Text = DataGridView1.Item(2, i).Value
        conn = GetConnect()

    End Sub
End Class