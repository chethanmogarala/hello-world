﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class frmProductsAndPrices

    Private Sub frmProductsAndPrices_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        conn = GetConnect()
       
        Try
            conn.Open()
            str = "INSERT INTO tblProductNPrice (Product, Price) VALUES (@Product, @Price)"
            'str = "Insert into tblProduct2 (Image1)" & "VALUES (@Image1)"
            cmd = New MySqlCommand(str, conn)
            With cmd
                ' Add parameters required by SQL statement. PictureID is an 
                ' identity field (in Microsoft Access, an AutoNumber field), 
                ' so you only need to pass values for the two remaining fields.

                .Parameters.Add(New MySqlParameter("@Product", _
                    MySqlDbType.VarChar)).Value = txtProduct.Text
                .Parameters.Add(New MySqlParameter("@Price", _
                   MySqlDbType.VarChar)).Value = txtProduct.Text
            End With
            cmd.ExecuteNonQuery()
            MsgBox("Data Saved Successfully!")

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class