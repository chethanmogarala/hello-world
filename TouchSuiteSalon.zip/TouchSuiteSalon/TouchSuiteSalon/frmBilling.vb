﻿Public Class frmBilling

    Private Sub frmBilling_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        lblDate.Text = Format(Now, "MMMM dd, yyyy")
        lblTime.Text = TimeOfDay
        lblTime.Text = Format(Now, "HH:mm:ss")
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class