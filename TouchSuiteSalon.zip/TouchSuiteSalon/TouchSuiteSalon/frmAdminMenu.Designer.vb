﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdminMenu))
        Me.btnAboutUS = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.btnProducts = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.btnServices = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnClients = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpiredToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QueueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnAboutUS
        '
        Me.btnAboutUS.BackgroundImage = CType(resources.GetObject("btnAboutUS.BackgroundImage"), System.Drawing.Image)
        Me.btnAboutUS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAboutUS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAboutUS.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnAboutUS.Location = New System.Drawing.Point(907, 499)
        Me.btnAboutUS.Name = "btnAboutUS"
        Me.btnAboutUS.Size = New System.Drawing.Size(460, 250)
        Me.btnAboutUS.TabIndex = 26
        Me.btnAboutUS.Text = "About Us"
        Me.btnAboutUS.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), System.Drawing.Image)
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button8.Location = New System.Drawing.Point(907, 249)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(460, 250)
        Me.Button8.TabIndex = 25
        Me.Button8.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.BackgroundImage = CType(resources.GetObject("btnReports.BackgroundImage"), System.Drawing.Image)
        Me.btnReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnReports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReports.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnReports.Location = New System.Drawing.Point(907, 27)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(460, 222)
        Me.btnReports.TabIndex = 24
        Me.btnReports.Text = "Comments"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), System.Drawing.Image)
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button6.Location = New System.Drawing.Point(451, 499)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(460, 250)
        Me.Button6.TabIndex = 23
        Me.Button6.UseVisualStyleBackColor = True
        '
        'btnProducts
        '
        Me.btnProducts.BackgroundImage = CType(resources.GetObject("btnProducts.BackgroundImage"), System.Drawing.Image)
        Me.btnProducts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnProducts.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProducts.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnProducts.Location = New System.Drawing.Point(451, 249)
        Me.btnProducts.Name = "btnProducts"
        Me.btnProducts.Size = New System.Drawing.Size(460, 250)
        Me.btnProducts.TabIndex = 22
        Me.btnProducts.Text = "Products"
        Me.btnProducts.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button4.Location = New System.Drawing.Point(451, 27)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(460, 222)
        Me.Button4.TabIndex = 21
        Me.Button4.UseVisualStyleBackColor = True
        '
        'btnServices
        '
        Me.btnServices.BackgroundImage = CType(resources.GetObject("btnServices.BackgroundImage"), System.Drawing.Image)
        Me.btnServices.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnServices.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnServices.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnServices.Location = New System.Drawing.Point(0, 499)
        Me.btnServices.Name = "btnServices"
        Me.btnServices.Size = New System.Drawing.Size(460, 250)
        Me.btnServices.TabIndex = 20
        Me.btnServices.Text = "Staffs"
        Me.btnServices.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.Button2.Location = New System.Drawing.Point(-5, 249)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(460, 250)
        Me.Button2.TabIndex = 19
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnClients
        '
        Me.btnClients.BackgroundImage = CType(resources.GetObject("btnClients.BackgroundImage"), System.Drawing.Image)
        Me.btnClients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnClients.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClients.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClients.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon
        Me.btnClients.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClients.Location = New System.Drawing.Point(0, 27)
        Me.btnClients.Name = "btnClients"
        Me.btnClients.Size = New System.Drawing.Size(460, 222)
        Me.btnClients.TabIndex = 18
        Me.btnClients.Text = "Services"
        Me.btnClients.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ExpiredToolStripMenuItem, Me.QueueToolStripMenuItem, Me.AboutUsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 27
        Me.MenuStrip1.Text = "&File"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "&File"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.CloseToolStripMenuItem.Text = "&Close"
        '
        'ExpiredToolStripMenuItem
        '
        Me.ExpiredToolStripMenuItem.Name = "ExpiredToolStripMenuItem"
        Me.ExpiredToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.ExpiredToolStripMenuItem.Text = "Membership"
        '
        'AboutUsToolStripMenuItem
        '
        Me.AboutUsToolStripMenuItem.Name = "AboutUsToolStripMenuItem"
        Me.AboutUsToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.AboutUsToolStripMenuItem.Text = "About &Us"
        '
        'QueueToolStripMenuItem
        '
        Me.QueueToolStripMenuItem.Name = "QueueToolStripMenuItem"
        Me.QueueToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.QueueToolStripMenuItem.Text = "Queue"
        '
        'frmAdminMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1370, 750)
        Me.Controls.Add(Me.btnAboutUS)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.btnProducts)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.btnServices)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnClients)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.Transparent
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmAdminMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAboutUS As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents btnReports As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents btnProducts As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents btnServices As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnClients As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExpiredToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutUsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QueueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
