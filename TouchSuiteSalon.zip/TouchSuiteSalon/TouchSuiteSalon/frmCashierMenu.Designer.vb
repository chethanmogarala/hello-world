﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCashierMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCashierMenu))
        Me.CloudDigitalClock1 = New CloudToolkitN6.CloudDigitalClock()
        Me.btnClients = New System.Windows.Forms.Button()
        Me.btnServices = New System.Windows.Forms.Button()
        Me.btnAboutUS = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CloudDigitalClock1
        '
        Me.CloudDigitalClock1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloudDigitalClock1.BackColor = System.Drawing.Color.Transparent
        Me.CloudDigitalClock1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CloudDigitalClock1.ColorLower_1 = System.Drawing.Color.Transparent
        Me.CloudDigitalClock1.ColorLower_2 = System.Drawing.Color.Transparent
        Me.CloudDigitalClock1.ColorUpper_1 = System.Drawing.Color.Transparent
        Me.CloudDigitalClock1.ColorUpper_2 = System.Drawing.Color.Transparent
        Me.CloudDigitalClock1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CloudDigitalClock1.DateColor = System.Drawing.Color.White
        Me.CloudDigitalClock1.DateFont = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.CloudDigitalClock1.DrawDate = True
        Me.CloudDigitalClock1.Location = New System.Drawing.Point(12, 27)
        Me.CloudDigitalClock1.Name = "CloudDigitalClock1"
        Me.CloudDigitalClock1.NumberColor = System.Drawing.Color.White
        Me.CloudDigitalClock1.NumberFont = New System.Drawing.Font("Microsoft Sans Serif", 50.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.CloudDigitalClock1.Size = New System.Drawing.Size(667, 333)
        Me.CloudDigitalClock1.TabIndex = 90
        '
        'btnClients
        '
        Me.btnClients.BackgroundImage = CType(resources.GetObject("btnClients.BackgroundImage"), System.Drawing.Image)
        Me.btnClients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnClients.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClients.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClients.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon
        Me.btnClients.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClients.Location = New System.Drawing.Point(690, 356)
        Me.btnClients.Name = "btnClients"
        Me.btnClients.Size = New System.Drawing.Size(682, 392)
        Me.btnClients.TabIndex = 91
        Me.btnClients.Text = "Members"
        Me.btnClients.UseVisualStyleBackColor = False
        '
        'btnServices
        '
        Me.btnServices.BackgroundImage = CType(resources.GetObject("btnServices.BackgroundImage"), System.Drawing.Image)
        Me.btnServices.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnServices.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnServices.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnServices.Location = New System.Drawing.Point(-7, 356)
        Me.btnServices.Name = "btnServices"
        Me.btnServices.Size = New System.Drawing.Size(704, 392)
        Me.btnServices.TabIndex = 92
        Me.btnServices.Text = "Staffs"
        Me.btnServices.UseVisualStyleBackColor = True
        '
        'btnAboutUS
        '
        Me.btnAboutUS.BackgroundImage = CType(resources.GetObject("btnAboutUS.BackgroundImage"), System.Drawing.Image)
        Me.btnAboutUS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAboutUS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAboutUS.Font = New System.Drawing.Font("Perpetua", 20.25!, System.Drawing.FontStyle.Bold)
        Me.btnAboutUS.Location = New System.Drawing.Point(690, 0)
        Me.btnAboutUS.Name = "btnAboutUS"
        Me.btnAboutUS.Size = New System.Drawing.Size(682, 360)
        Me.btnAboutUS.TabIndex = 93
        Me.btnAboutUS.Text = "Billing"
        Me.btnAboutUS.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 94
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'frmCashierMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1370, 750)
        Me.Controls.Add(Me.btnAboutUS)
        Me.Controls.Add(Me.btnServices)
        Me.Controls.Add(Me.btnClients)
        Me.Controls.Add(Me.CloudDigitalClock1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.Transparent
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmCashierMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Touch Salon System: Cashier Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CloudDigitalClock1 As CloudToolkitN6.CloudDigitalClock
    Friend WithEvents btnClients As System.Windows.Forms.Button
    Friend WithEvents btnServices As System.Windows.Forms.Button
    Friend WithEvents btnAboutUS As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
