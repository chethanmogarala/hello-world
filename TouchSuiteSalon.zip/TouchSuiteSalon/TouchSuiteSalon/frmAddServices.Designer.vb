﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddServices
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddServices))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnClose = New CloudToolkitN6.CloudDesktopButton()
        Me.btnDelete = New CloudToolkitN6.CloudDesktopButton()
        Me.btnUpdate = New CloudToolkitN6.CloudDesktopButton()
        Me.btnCancel = New CloudToolkitN6.CloudDesktopButton()
        Me.btnSave = New CloudToolkitN6.CloudDesktopButton()
        Me.txtServiceID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.txtService = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.cmbCategory = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(452, 95)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(345, 259)
        Me.DataGridView1.TabIndex = 32
        '
        'btnClose
        '
        Me.btnClose.AnimationSpeed = 5
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.BackgroundImage = CType(resources.GetObject("btnClose.BackgroundImage"), System.Drawing.Image)
        Me.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnClose.BackgroundOpacity = 100
        Me.btnClose.BackgroundOpacity_MouseDown = 170
        Me.btnClose.BorderColor = System.Drawing.Color.White
        Me.btnClose.BorderOpacity = 170
        Me.btnClose.BorderWidth = 1
        Me.btnClose.ControlText = "CLOSE"
        Me.btnClose.CornerRadius = 12
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBlackTextBackground = True
        Me.btnClose.FillColor = System.Drawing.Color.Azure
        Me.btnClose.ForeColor = System.Drawing.Color.White
        Me.btnClose.Icon = Nothing
        Me.btnClose.Location = New System.Drawing.Point(713, 410)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(67, 76)
        Me.btnClose.TabIndex = 27
        '
        'btnDelete
        '
        Me.btnDelete.AnimationSpeed = 5
        Me.btnDelete.BackColor = System.Drawing.Color.Transparent
        Me.btnDelete.BackgroundImage = CType(resources.GetObject("btnDelete.BackgroundImage"), System.Drawing.Image)
        Me.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDelete.BackgroundOpacity = 100
        Me.btnDelete.BackgroundOpacity_MouseDown = 170
        Me.btnDelete.BorderColor = System.Drawing.Color.White
        Me.btnDelete.BorderOpacity = 170
        Me.btnDelete.BorderWidth = 1
        Me.btnDelete.ControlText = "DELETE"
        Me.btnDelete.CornerRadius = 12
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DrawBlackTextBackground = True
        Me.btnDelete.FillColor = System.Drawing.Color.Azure
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Icon = Nothing
        Me.btnDelete.Location = New System.Drawing.Point(386, 401)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(65, 76)
        Me.btnDelete.TabIndex = 25
        '
        'btnUpdate
        '
        Me.btnUpdate.AnimationSpeed = 5
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BackgroundImage = CType(resources.GetObject("btnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.btnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnUpdate.BackgroundOpacity = 100
        Me.btnUpdate.BackgroundOpacity_MouseDown = 170
        Me.btnUpdate.BorderColor = System.Drawing.Color.White
        Me.btnUpdate.BorderOpacity = 170
        Me.btnUpdate.BorderWidth = 1
        Me.btnUpdate.ControlText = "UPDATE"
        Me.btnUpdate.CornerRadius = 12
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.DrawBlackTextBackground = True
        Me.btnUpdate.FillColor = System.Drawing.Color.Azure
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Icon = Nothing
        Me.btnUpdate.Location = New System.Drawing.Point(270, 401)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(66, 76)
        Me.btnUpdate.TabIndex = 24
        '
        'btnCancel
        '
        Me.btnCancel.AnimationSpeed = 5
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.BackgroundImage = CType(resources.GetObject("btnCancel.BackgroundImage"), System.Drawing.Image)
        Me.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnCancel.BackgroundOpacity = 100
        Me.btnCancel.BackgroundOpacity_MouseDown = 170
        Me.btnCancel.BorderColor = System.Drawing.Color.White
        Me.btnCancel.BorderOpacity = 170
        Me.btnCancel.BorderWidth = 1
        Me.btnCancel.ControlText = "CLEAR"
        Me.btnCancel.CornerRadius = 12
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBlackTextBackground = True
        Me.btnCancel.FillColor = System.Drawing.Color.Azure
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Icon = Nothing
        Me.btnCancel.Location = New System.Drawing.Point(160, 401)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(64, 76)
        Me.btnCancel.TabIndex = 23
        '
        'btnSave
        '
        Me.btnSave.AnimationSpeed = 5
        Me.btnSave.BackColor = System.Drawing.Color.Transparent
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSave.BackgroundOpacity = 100
        Me.btnSave.BackgroundOpacity_MouseDown = 170
        Me.btnSave.BorderColor = System.Drawing.Color.White
        Me.btnSave.BorderOpacity = 170
        Me.btnSave.BorderWidth = 1
        Me.btnSave.ControlText = "ADD"
        Me.btnSave.CornerRadius = 12
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBlackTextBackground = True
        Me.btnSave.FillColor = System.Drawing.Color.Azure
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Icon = Nothing
        Me.btnSave.Location = New System.Drawing.Point(41, 401)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(71, 76)
        Me.btnSave.TabIndex = 22
        '
        'txtServiceID
        '
        Me.txtServiceID.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtServiceID.Location = New System.Drawing.Point(199, 95)
        Me.txtServiceID.Name = "txtServiceID"
        Me.txtServiceID.ReadOnly = True
        Me.txtServiceID.Size = New System.Drawing.Size(221, 27)
        Me.txtServiceID.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(28, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 29)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Service ID:"
        '
        'txtPrice
        '
        Me.txtPrice.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice.Location = New System.Drawing.Point(199, 327)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(221, 27)
        Me.txtPrice.TabIndex = 21
        '
        'txtService
        '
        Me.txtService.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtService.Location = New System.Drawing.Point(199, 245)
        Me.txtService.Name = "txtService"
        Me.txtService.Size = New System.Drawing.Size(221, 27)
        Me.txtService.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(28, 325)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 29)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Price:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(28, 245)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 29)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Service:"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(295, 25)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(244, 29)
        Me.lblTitle.TabIndex = 26
        Me.lblTitle.Text = "Services and Price "
        '
        'cmbCategory
        '
        Me.cmbCategory.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Bold)
        Me.cmbCategory.FormattingEnabled = True
        Me.cmbCategory.Items.AddRange(New Object() {"Hair and Nail Care", "Hair Coloring", "Hair Treatments and Form", "Waxing / Threading"})
        Me.cmbCategory.Location = New System.Drawing.Point(199, 170)
        Me.cmbCategory.Name = "cmbCategory"
        Me.cmbCategory.Size = New System.Drawing.Size(221, 27)
        Me.cmbCategory.TabIndex = 33
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(28, 170)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 29)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Category: "
        '
        'frmAddServices
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(904, 520)
        Me.Controls.Add(Me.cmbCategory)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtServiceID)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtService)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTitle)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAddServices"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Services"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btnClose As CloudToolkitN6.CloudDesktopButton
    Friend WithEvents btnDelete As CloudToolkitN6.CloudDesktopButton
    Friend WithEvents btnUpdate As CloudToolkitN6.CloudDesktopButton
    Friend WithEvents btnCancel As CloudToolkitN6.CloudDesktopButton
    Friend WithEvents btnSave As CloudToolkitN6.CloudDesktopButton
    Friend WithEvents txtServiceID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtService As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents cmbCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
