﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class Login
    Dim ctr As Integer

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        conn = GetConnect()
        Try
            conn.Open()
            str = "Select UserName, Password from tblUser where UserName = '" & Trim(txtUserName.Text) & "' and Password = '" & Trim(txtPassword.Text) & "'"
            cmd = New MySqlCommand(str, conn)
            dr = cmd.ExecuteReader

            If dr.HasRows = True Then
                '   MsgBox("Access Granted")

                dr.Close()

                str2 = "Select * from tblUser where UserName = '" & Trim(txtUserName.Text) & "' and Password = '" & Trim(txtPassword.Text) & "' and Auth = 'admin'"
                cmd2 = New MySqlCommand(str2, conn)
                dr2 = cmd2.ExecuteReader

                If dr2.HasRows = True Then

                    Dim Menu As New Form1
                    Menu.Show()
                    Me.Hide()

                End If


                If dr2.HasRows = False Then
                    dr2.Close()
                    str3 = "Select * from tblUser where UserName = '" & Trim(txtUserName.Text) & "' and Password = '" & Trim(txtPassword.Text) & "' and Auth = 'cashier'"
                    cmd3 = New MySqlCommand(str3, conn)
                    dr3 = cmd3.ExecuteReader

                    If dr3.HasRows = True Then
                        Dim frmCashierMenu As New frmCashierMenu
                        frmCashierMenu.Show()
                        Me.Hide()
                    Else
                        Dim GuestForm As New FrmGuestMenu
                        GuestForm.Show()
                        Me.Hide()
                    End If

                End If



            ElseIf txtUserName.Text = "" Or txtPassword.Text = "" Then
                MsgBox("Enter Value!")
                txtUserName.Text = ""
                ctr = ctr - 1
                If ctr = 0 Then
                    'MessageBox.Show("You entered 3 times incorrect !")
                    MsgBox("You already tried 3 incorrect username or passowrd. Try again Later", _
               vbCritical, "Restricted Access!")

                    End
                End If
            Else
                MsgBox("Invalid UserName/Password")
                txtUserName.Text = ""
                txtPassword.Text = ""
                txtUserName.Focus()
                ctr = ctr - 1
                If ctr = 0 Then
                    MsgBox("You already tried 3 incorrect username or passowrd. Try again Later", _
               vbCritical, "Restricted Access!")

                    End
                End If
            End If

            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Dim i As Integer
        i = MsgBox("Are you sure you want to exit application?", vbYesNo, "Enrollemt System")
        If i = vbYes Then
            End
        End If

    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtUserName.Focus()
        ctr = 3
    End Sub

    Private Sub txtPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtUserName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUserName.TextChanged

    End Sub
End Class